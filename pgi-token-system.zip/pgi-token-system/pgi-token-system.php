<?php
/**
 * Plugin Name: PGI Token System
 * Description: Hospital patient token and queue system (kiosk, TV displays, counter, doctor and attendant screens) as an installable phone app with push notifications.
 * Version: 3.0.2
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: ANS Token System
 * License: GPLv2 or later
 * Text Domain: pgi-token
 */

if (!defined('ABSPATH')) exit;

define('PGI_VERSION', '3.0.2');
define('PGI_DIR', plugin_dir_path(__FILE__));
define('PGI_URL', plugin_dir_url(__FILE__));
define('PGI_SLUG', 'token'); // the app lives at https://your-site/token/

require_once PGI_DIR . 'includes/db.php';
require_once PGI_DIR . 'includes/core.php';
require_once PGI_DIR . 'includes/push.php';
require_once PGI_DIR . 'includes/rest.php';
require_once PGI_DIR . 'includes/app.php';
require_once PGI_DIR . 'includes/setup.php';
require_once PGI_DIR . 'includes/update.php';

register_activation_hook(__FILE__, 'pgi_activate');
register_deactivation_hook(__FILE__, function () { flush_rewrite_rules(); });

function pgi_activate() {
	pgi_install_tables();
	pgi_add_roles();
	pgi_app_rewrite();
	flush_rewrite_rules();
	if (!get_option('pgi_setup_done')) set_transient('pgi_redirect_setup', 1, 60);
}

// Upgrade tables when the plugin files are replaced with a newer version
add_action('plugins_loaded', function () {
	if (get_option('pgi_db_version') !== PGI_VERSION) { pgi_install_tables(); pgi_add_roles(); update_option('pgi_db_version', PGI_VERSION); }
});
