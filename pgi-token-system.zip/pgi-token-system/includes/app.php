<?php
if (!defined('ABSPATH')) exit;

/*
 * Serves the app screens at https://your-site/token/ (kiosk, TV, counter, doctor, attendant, admin, patient status).
 * Each page gets the WordPress REST address and a security nonce, plus the manifest and icons
 * that let phones install it as an app.
 */

function pgi_app_rewrite() {
	add_rewrite_rule('^' . PGI_SLUG . '/?$', 'index.php?pgi_page=index.html', 'top');
	add_rewrite_rule('^' . PGI_SLUG . '/([A-Za-z0-9_.-]+)$', 'index.php?pgi_page=$matches[1]', 'top');
}
add_action('init', 'pgi_app_rewrite');
add_filter('query_vars', function ($v) { $v[] = 'pgi_page'; return $v; });

function pgi_app_base() { return wp_make_link_relative(home_url('/' . PGI_SLUG . '/')); }
const PGI_TYPES = ['html' => 'text/html; charset=utf-8', 'js' => 'application/javascript; charset=utf-8', 'css' => 'text/css; charset=utf-8',
	'svg' => 'image/svg+xml', 'png' => 'image/png', 'json' => 'application/manifest+json; charset=utf-8'];

// Pages people can add to the Home Screen; the installed app opens on the page it was added from
function pgi_app_pages() {
	return ['index.html' => 'Token System', 'kiosk.html' => 'Token Kiosk', 'display.html' => 'Hall Display', 'room.html' => 'Room Display', 'counter.html' => 'Counter',
		'doctor.html' => 'Doctor Desk', 'ha.html' => 'Room Attendant', 'admin.html' => 'Token Admin', 'status.html' => 'My Token', 'slip.html' => 'Token Slip'];
}

add_action('parse_request', function ($wp) {
	if (empty($wp->query_vars['pgi_page'])) return;
	pgi_app_serve(basename((string) $wp->query_vars['pgi_page']));
});

function pgi_app_serve($page) {
	if (!preg_match('/^[A-Za-z0-9_-]+\.(html|js|css|svg|png|json)$/', $page, $m)) { status_header(404); exit('Not found'); }
	$ext = $m[1];
	if ($page === 'manifest.json') pgi_app_manifest();
	$file = PGI_DIR . 'app/' . $page;
	if (!is_file($file)) { status_header(404); exit('Not found'); }
	status_header(200);
	header('Content-Type: ' . PGI_TYPES[$ext]);
	header('X-Content-Type-Options: nosniff');
	if ($page === 'sw.js') {
		header('Cache-Control: no-cache');
		header('Service-Worker-Allowed: ' . pgi_app_base());
		readfile($file); exit;
	}
	if ($ext !== 'html') { // versioned with ?v= in the pages, so browsers may keep them
		header('Cache-Control: public, max-age=' . (isset($_GET['v']) ? 604800 : 3600));
		readfile($file); exit;
	}
	nocache_headers(); // pages carry a fresh nonce
	echo pgi_app_html(file_get_contents($file), $page);
	exit;
}

function pgi_app_html($html, $page) {
	$s = pgi_settings();
	$cfg = ['api' => wp_make_link_relative(esc_url_raw(rest_url('pgi-token/v1/'))), 'nonce' => wp_create_nonce('wp_rest'), 'base' => pgi_app_base(), 'vapid' => pgi_vapid_public(), 'page' => $page, 'app' => PGI_VERSION];
	$start = $page . (!empty($_SERVER['QUERY_STRING']) && in_array($page, ['ha.html', 'room.html', 'display.html', 'status.html', 'doctor.html'], true) ? '?' . $_SERVER['QUERY_STRING'] : '');
	$title = esc_attr(pgi_app_pages()[$page] ?? 'Token System');
	$head = '<script>window.PGI=' . wp_json_encode($cfg) . ';</script>'
		. '<link rel="manifest" href="manifest.json?start=' . rawurlencode($start) . '">'
		. '<link rel="icon" href="favicon.svg" type="image/svg+xml"><link rel="apple-touch-icon" href="icon-180.png">'
		. '<meta name="apple-mobile-web-app-capable" content="yes"><meta name="mobile-web-app-capable" content="yes">'
		. '<meta name="apple-mobile-web-app-status-bar-style" content="default"><meta name="apple-mobile-web-app-title" content="' . $title . '">';
	$html = preg_replace('/(\.(?:js|css))\?v=(\d+)/', '$1?v=$2-' . PGI_VERSION, $html); // new plugin version = fresh scripts
	return preg_replace('/<meta charset="utf-8">/i', '<meta charset="utf-8">' . $head, $html, 1);
}

function pgi_app_manifest() {
	$s = pgi_settings(); $pages = pgi_app_pages();
	$start = (string) ($_GET['start'] ?? 'index.html');
	$p = strtok($start, '?');
	if (!isset($pages[$p]) || preg_match('/[^A-Za-z0-9_.=&%?-]/', $start)) { $start = 'index.html'; $p = 'index.html'; }
	$color = ['teal' => '#0f766e', 'blue' => '#1d4ed8', 'green' => '#15803d', 'purple' => '#6d28d9', 'maroon' => '#9f1239', 'orange' => '#c2410c', 'contrast' => '#000000', 'night' => '#0b1418'][$s['theme']] ?? '#0f766e';
	$base = pgi_app_base();
	nocache_headers();
	header('Content-Type: ' . PGI_TYPES['json']);
	echo wp_json_encode([
		'id' => $base . $p, 'name' => $pages[$p] . ' · ' . ($s['building'] ?: wp_strip_all_tags($s['hospital'])), 'short_name' => $pages[$p],
		'description' => 'Patient tokens and queue · ' . wp_strip_all_tags($s['hospital']),
		'start_url' => $base . $start, 'scope' => $base, 'display' => 'standalone', 'orientation' => 'any',
		'background_color' => '#ffffff', 'theme_color' => $color,
		'icons' => [
			['src' => $base . 'icon-192.png', 'sizes' => '192x192', 'type' => 'image/png', 'purpose' => 'any'],
			['src' => $base . 'icon-512.png', 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'any'],
			['src' => $base . 'icon-maskable.png', 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'maskable'],
		],
	], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
	exit;
}
