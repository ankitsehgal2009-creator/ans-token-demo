<?php
if (!defined('ABSPATH')) exit;

// Table name helper: pgi_t('tokens') -> wp_pgi_tokens
function pgi_t($name) { global $wpdb; return $wpdb->prefix . 'pgi_' . $name; }

function pgi_install_tables() {
	global $wpdb;
	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	$c = $wpdb->get_charset_collate();
	$sql = [
		"CREATE TABLE " . pgi_t('departments') . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  code varchar(4) NOT NULL,
  name varchar(80) NOT NULL,
  name_local varchar(80) NOT NULL DEFAULT '',
  color varchar(9) NOT NULL DEFAULT '#0f766e',
  active tinyint(1) NOT NULL DEFAULT 1,
  sort int(11) NOT NULL DEFAULT 0,
  days varchar(20) NOT NULL DEFAULT '',
  location varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY  (id),
  UNIQUE KEY code (code)
) $c;",
		"CREATE TABLE " . pgi_t('doctor_types') . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  name varchar(40) NOT NULL,
  active tinyint(1) NOT NULL DEFAULT 1,
  sort int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY  (id)
) $c;",
		"CREATE TABLE " . pgi_t('doctors') . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  name varchar(80) NOT NULL,
  dept bigint(20) unsigned DEFAULT NULL,
  room int(11) DEFAULT NULL,
  days varchar(20) NOT NULL DEFAULT '',
  active tinyint(1) NOT NULL DEFAULT 1,
  type bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY  (id)
) $c;",
		"CREATE TABLE " . pgi_t('tokens') . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  day varchar(10) NOT NULL,
  token varchar(12) NOT NULL,
  num int(11) NOT NULL,
  dept bigint(20) unsigned NOT NULL,
  priority tinyint(1) NOT NULL DEFAULT 0,
  status varchar(12) NOT NULL,
  name varchar(80) NOT NULL DEFAULT '',
  phone varchar(15) NOT NULL DEFAULT '',
  age varchar(3) NOT NULL DEFAULT '',
  gender varchar(10) NOT NULL DEFAULT '',
  note varchar(200) NOT NULL DEFAULT '',
  counter int(11) DEFAULT NULL,
  room int(11) DEFAULT NULL,
  doctor bigint(20) unsigned DEFAULT NULL,
  floor varchar(40) DEFAULT NULL,
  secret varchar(16) NOT NULL,
  source varchar(10) NOT NULL DEFAULT 'kiosk',
  created varchar(24) DEFAULT NULL,
  called_at varchar(24) DEFAULT NULL,
  registered_at varchar(24) DEFAULT NULL,
  room_at varchar(24) DEFAULT NULL,
  done_at varchar(24) DEFAULT NULL,
  updated varchar(24) DEFAULT NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY day_token (day,token),
  KEY day_status (day,status)
) $c;",
		"CREATE TABLE " . pgi_t('audit') . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  ts varchar(24) NOT NULL,
  user varchar(60) NOT NULL DEFAULT '',
  action varchar(40) NOT NULL,
  token varchar(12) DEFAULT NULL,
  place varchar(60) DEFAULT NULL,
  details varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY  (id)
) $c;",
		"CREATE TABLE " . pgi_t('checkins') . " (
  day varchar(10) NOT NULL,
  doctor bigint(20) unsigned NOT NULL,
  room int(11) NOT NULL,
  at varchar(24) DEFAULT NULL,
  PRIMARY KEY  (day,doctor)
) $c;",
		"CREATE TABLE " . pgi_t('push_subs') . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  endpoint text NOT NULL,
  hash char(40) NOT NULL,
  p256dh varchar(120) NOT NULL DEFAULT '',
  auth varchar(40) NOT NULL DEFAULT '',
  kind varchar(10) NOT NULL,
  room int(11) DEFAULT NULL,
  doctor bigint(20) unsigned DEFAULT NULL,
  token_id bigint(20) unsigned DEFAULT NULL,
  user_id bigint(20) unsigned NOT NULL DEFAULT 0,
  created varchar(24) DEFAULT NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY hash (hash),
  KEY kind_room (kind,room)
) $c;",
	];
	foreach ($sql as $q) dbDelta($q);
}

// Staff roles. WordPress administrators also get every PGI capability.
function pgi_add_roles() {
	$caps = ['read' => true];
	add_role('pgi_admin', 'PGI Token admin', $caps + ['pgi_admin' => true, 'pgi_counter' => true, 'pgi_doctor' => true, 'pgi_ha' => true]);
	add_role('pgi_counter', 'PGI Registration counter', $caps + ['pgi_counter' => true]);
	add_role('pgi_doctor', 'PGI Doctor', $caps + ['pgi_doctor' => true]);
	add_role('pgi_ha', 'PGI Room attendant', $caps + ['pgi_ha' => true]);
	$a = get_role('administrator');
	if ($a) foreach (['pgi_admin', 'pgi_counter', 'pgi_doctor', 'pgi_ha'] as $cap) $a->add_cap($cap);
}
