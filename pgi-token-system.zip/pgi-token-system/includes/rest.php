<?php
if (!defined('ABSPATH')) exit;

// ---------- who is signed in ----------
function pgi_role() {
	if (!is_user_logged_in()) return null;
	foreach (['pgi_admin' => 'admin', 'pgi_counter' => 'counter', 'pgi_doctor' => 'doctor', 'pgi_ha' => 'ha'] as $cap => $r) if (current_user_can($cap)) return $r;
	return null;
}
function pgi_user() { $u = wp_get_current_user(); return $u && $u->ID ? $u->user_login : 'kiosk'; }
// Permission callback: allowed roles (admin is always allowed)
function pgi_perm(...$roles) {
	return function () use ($roles) {
		$r = pgi_role();
		if (!$r) return new WP_Error('pgi_auth', 'Sign in required', ['status' => 401]);
		return $r === 'admin' || in_array($r, $roles, true) ? true : new WP_Error('pgi_forbidden', 'Not authorised', ['status' => 403]);
	};
}
function pgi_err($msg, $code = 400) { return new WP_REST_Response(['error' => $msg], $code); }
function pgi_ok($data = []) { return new WP_REST_Response(['ok' => true] + $data); }
function pgi_done($data = []) { pgi_bump(); return pgi_ok($data); }
// Text downloads (CSV) are written directly instead of JSON
function pgi_send_csv($name, $keys, $rows) {
	nocache_headers();
	header('Content-Type: text/csv; charset=utf-8');
	header('Content-Disposition: attachment; filename="' . $name . '"');
	echo "\xEF\xBB\xBF" . implode(',', $keys) . "\r\n"; // BOM so Excel shows Hindi correctly
	foreach ($rows as $x) echo implode(',', array_map(function ($k) use ($x) { return '"' . str_replace('"', '""', (string) ($x[$k] ?? '')) . '"'; }, $keys)) . "\r\n";
	exit;
}

add_action('rest_api_init', function () {
	$ns = 'pgi-token/v1';
	$pub = '__return_true';
	$route = function ($path, $method, $cb, $perm) use ($ns) {
		register_rest_route($ns, '/' . $path, ['methods' => $method, 'callback' => function (WP_REST_Request $q) use ($cb) {
			pgi_day_check();
			return $cb($q->get_json_params() ?: [], $q);
		}, 'permission_callback' => $perm]);
	};

	// ----- public -----
	$route('state', 'GET', function ($b, $q) {
		$v = (int) $q->get_param('v');
		if ($v > 0 && $v === pgi_version()) return ['same' => true, 'version' => $v, 'app' => PGI_VERSION];
		return pgi_state(pgi_role() !== null);
	}, $pub);
	$route('me', 'GET', function () { $u = wp_get_current_user(); return ['role' => pgi_role(), 'user' => $u->ID ? $u->user_login : null]; }, $pub);
	$route('tips', 'GET', function () { return ['tips' => array_values(array_filter(array_map('trim', file(PGI_DIR . 'includes/tips.txt')))) ]; }, $pub);
	$route('login', 'POST', function ($b) {
		$u = wp_signon(['user_login' => sanitize_user($b['user'] ?? ''), 'user_password' => (string) ($b['pass'] ?? ''), 'remember' => false], is_ssl());
		if (is_wp_error($u)) return pgi_err('Incorrect username or password', 401);
		wp_set_current_user($u->ID);
		$r = pgi_role();
		if (!$r) { wp_logout(); return pgi_err('This account has no access to the token system', 403); }
		pgi_log('login', null, null, '', $u->user_login);
		return ['role' => $r, 'user' => $u->user_login];
	}, $pub);
	$route('logout', 'POST', function () { wp_logout(); return pgi_ok(); }, $pub);

	// Issue a token (kiosk = public, counter/admin = walk-in)
	$route('token', 'POST', function ($b) {
		global $wpdb;
		$s = pgi_settings(); $role = pgi_role(); $staff = in_array($role, ['counter', 'admin'], true);
		$d = null; foreach (pgi_depts() as $x) if ($x['id'] === (int) ($b['dept'] ?? 0) && $x['active']) $d = $x;
		if (!$d) return pgi_err('Please choose a department');
		if (!$d['openToday'] && !$staff) return pgi_err($d['name'] . ' OPD is not running today');
		$priority = max(0, min(2, (int) ($b['priority'] ?? 0)));
		if ($priority === 2 && empty($s['kioskEmergency']) && !$staff) $priority = 0;
		$day = pgi_today(); $ts = pgi_now(); $floor = pgi_pick_floor($s); $id = 0;
		for ($try = 0; $try < 6 && !$id; $try++) { // the unique (day, token) key stops two kiosks getting the same number
			$num = (int) $wpdb->get_var($wpdb->prepare("SELECT MAX(num) FROM " . pgi_t('tokens') . " WHERE day=%s AND dept=%d", $day, $d['id'])) + 1;
			$ok = $wpdb->insert(pgi_t('tokens'), ['day' => $day, 'token' => $d['code'] . '-' . str_pad($num, 3, '0', STR_PAD_LEFT), 'num' => $num, 'dept' => $d['id'], 'priority' => $priority,
				'status' => 'waiting', 'name' => pgi_clean($b['name'] ?? ''), 'phone' => pgi_clean($b['phone'] ?? '', 15), 'age' => pgi_clean($b['age'] ?? '', 3), 'gender' => pgi_clean($b['gender'] ?? '', 10),
				'floor' => $floor, 'secret' => bin2hex(random_bytes(6)), 'source' => $staff ? 'staff' : 'kiosk', 'created' => $ts, 'updated' => $ts]);
			if ($ok) $id = $wpdb->insert_id;
		}
		if (!$id) return pgi_err('Could not issue a token, please try again', 500);
		$t = pgi_find_token($id);
		pgi_log('issue-token', $t['token'], $floor, "dept={$d['code']} priority=" . PGI_PRIORITY[$priority], $staff ? pgi_user() : 'kiosk');
		pgi_bump();
		return pgi_slip_info($t, $s);
	}, $pub);

	// Patient status page (needs the secret printed in the QR code)
	$route('status', 'GET', function ($b, $q) {
		global $wpdb;
		$t = pgi_int_fields($wpdb->get_row($wpdb->prepare("SELECT * FROM " . pgi_t('tokens') . " WHERE id=%d AND secret=%s", (int) $q->get_param('id'), (string) $q->get_param('k')), ARRAY_A), PGI_TOKEN_INTS);
		if (!$t) return pgi_err('Token not found', 404);
		$s = pgi_settings(); $info = pgi_slip_info($t, $s);
		if ($t['status'] === 'consult') {
			$info['ahead'] = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM " . pgi_t('tokens') . " WHERE day=%s AND status='consult' AND " .
				($t['room'] ? $wpdb->prepare('(room=%d OR room IS NULL)', $t['room']) : '1=1') . " AND (priority>%d OR (priority=%d AND registered_at<%s))", $t['day'], $t['priority'], $t['priority'], $t['registered_at']));
			$info['waitMinutes'] = pgi_wait_for($s, $info['ahead']);
		}
		return $info + ['counter' => $t['counter'], 'hospital' => $s['hospital'], 'building' => $s['building'], 'notes' => $s['patientNotes'], 'scheduleUrl' => $s['scheduleUrl'], 'today' => $t['day'] === pgi_today()];
	}, $pub);

	$route('slip', 'GET', function ($b, $q) {
		$t = pgi_find_token($q->get_param('id'));
		if (!$t) return pgi_err('Token not found', 404);
		return pgi_slip_info($t, pgi_settings()) + ['name' => $t['name']];
	}, pgi_perm('counter', 'doctor'));

	// ----- counter -----
	$to_counter = function ($t, $c, $action) {
		pgi_update_token($t['id'], ['status' => 'called', 'counter' => $c['no'], 'floor' => ($c['floor'] ?? '') ?: null, 'called_at' => $t['called_at'] ?: pgi_now()]);
		$call = pgi_set_call($t, 'counter', $c['no'], $c['floor'] ?? null);
		pgi_log($action, $t['token'], trim('Counter ' . $c['no'] . ' ' . ($c['floor'] ?? '')));
		return pgi_done(['token' => $t['token'], 'call' => $call]);
	};
	$route('call', 'POST', function ($b) use ($to_counter) {
		global $wpdb;
		$s = pgi_settings(); $c = pgi_counter_of($s, $b['counter'] ?? 0);
		if (!$c) return pgi_err('Choose your counter');
		$busy = $wpdb->get_var($wpdb->prepare("SELECT token FROM " . pgi_t('tokens') . " WHERE day=%s AND status='called' AND counter=%d", pgi_today(), $c['no']));
		if ($busy) return pgi_err("Counter {$c['no']} is still serving $busy");
		$ids = array_values(array_filter(array_map('intval', (array) ($b['depts'] ?? []))));
		$filter = $ids ? ' AND dept IN (' . implode(',', $ids) . ')' : '';
		$t = pgi_int_fields($wpdb->get_row($wpdb->prepare("SELECT * FROM " . pgi_t('tokens') . " WHERE day=%s AND status='waiting' AND (floor IS NULL OR floor=%s) $filter ORDER BY priority DESC, id ASC LIMIT 1", pgi_today(), $c['floor'] ?? ''), ARRAY_A), PGI_TOKEN_INTS);
		if (!$t) return pgi_err('No one is waiting' . (!empty($c['floor']) ? ' on the ' . $c['floor'] : ''), 404);
		return $to_counter($t, $c, 'call-next');
	}, pgi_perm('counter'));
	$route('call-token', 'POST', function ($b) use ($to_counter) {
		$s = pgi_settings(); $c = pgi_counter_of($s, $b['counter'] ?? 0); $t = pgi_find_token($b['id'] ?? 0);
		if (!$c) return pgi_err('Choose your counter');
		if (!$t || !in_array($t['status'], ['waiting', 'skipped'], true)) return pgi_err('Token cannot be called');
		return $to_counter($t, $c, 'call-token');
	}, pgi_perm('counter'));
	$route('recall', 'POST', function ($b) {
		$s = pgi_settings(); $t = pgi_find_token($b['id'] ?? 0);
		if (!$t || !in_array($t['status'], ['called', 'room'], true)) return pgi_err('Token cannot be recalled');
		if ($t['status'] === 'room') { $rm = pgi_room_of($s, $t['room']); $call = pgi_set_call($t, 'room', $rm['no'] ?? $t['room'], $rm['floor'] ?? null); }
		else $call = pgi_set_call($t, 'counter', $t['counter'], pgi_counter_of($s, $t['counter'])['floor'] ?? null);
		pgi_log('recall', $t['token'], $call['kind'] . ' ' . $call['place']);
		return pgi_done(['call' => $call]);
	}, pgi_perm('counter', 'doctor', 'ha'));
	$route('patient', 'POST', function ($b) {
		$t = pgi_find_token($b['id'] ?? 0); if (!$t) return pgi_err('Token not found', 404);
		pgi_update_token($t['id'], ['name' => pgi_clean($b['name'] ?? ''), 'phone' => pgi_clean($b['phone'] ?? '', 15), 'age' => pgi_clean($b['age'] ?? '', 3), 'gender' => pgi_clean($b['gender'] ?? '', 10), 'note' => pgi_clean($b['note'] ?? '', 200)]);
		pgi_log('update-patient', $t['token']);
		return pgi_done();
	}, pgi_perm('counter', 'doctor'));
	// Registration done: optionally a doctor (and so a room) or a room directly
	$route('register', 'POST', function ($b) {
		global $wpdb;
		$s = pgi_settings(); $t = pgi_find_token($b['id'] ?? 0);
		if (!$t || $t['status'] !== 'called') return pgi_err('Token is not at a counter');
		$dept = (int) ($b['dept'] ?? 0) ?: $t['dept'];
		$doc = !empty($b['doctor']) ? pgi_int_fields($wpdb->get_row($wpdb->prepare("SELECT * FROM " . pgi_t('doctors') . " WHERE id=%d", $b['doctor']), ARRAY_A), ['id', 'room']) : null;
		$rm = pgi_room_of($s, ($b['room'] ?? 0) ?: ($doc['room'] ?? 0)); $room = $rm ? (int) $rm['id'] : null;
		pgi_update_token($t['id'], ['status' => 'consult', 'dept' => $dept, 'doctor' => $doc['id'] ?? null, 'room' => $room, 'registered_at' => pgi_now()]);
		pgi_log('registration-complete', $t['token'], 'Counter ' . $t['counter'], implode(', ', array_filter([$doc ? 'Dr ' . $doc['name'] : '', $rm ? 'Room ' . $rm['no'] : ''])));
		pgi_push_new_patient($t['token'], $room, $doc['id'] ?? null);
		return pgi_done();
	}, pgi_perm('counter'));
	$route('priority', 'POST', function ($b) {
		$t = pgi_find_token($b['id'] ?? 0); $p = max(0, min(2, (int) ($b['priority'] ?? 0)));
		if (!$t) return pgi_err('Token not found', 404);
		pgi_update_token($t['id'], ['priority' => $p]); pgi_log('set-priority', $t['token'], null, PGI_PRIORITY[$p]);
		return pgi_done();
	}, pgi_perm('counter', 'doctor'));
	$route('skip', 'POST', function ($b) {
		$t = pgi_find_token($b['id'] ?? 0);
		if (!$t || in_array($t['status'], ['done', 'cancelled'], true)) return pgi_err('Token cannot be skipped');
		pgi_update_token($t['id'], ['status' => 'skipped']);
		pgi_log('skip-no-show', $t['token'], $t['status'] === 'room' ? 'Room ' . $t['room'] : ($t['counter'] ? 'Counter ' . $t['counter'] : null));
		return pgi_done();
	}, pgi_perm('counter', 'doctor', 'ha'));
	$route('restore', 'POST', function ($b) {
		$t = pgi_find_token($b['id'] ?? 0);
		if (!$t || !in_array($t['status'], ['skipped', 'cancelled'], true)) return pgi_err('Token cannot be restored');
		$back = $t['registered_at'] ? 'consult' : 'waiting';
		pgi_update_token($t['id'], ['status' => $back]); pgi_log('restore', $t['token'], null, 'to ' . $back);
		return pgi_done();
	}, pgi_perm('counter', 'doctor'));
	$route('cancel', 'POST', function ($b) {
		$t = pgi_find_token($b['id'] ?? 0);
		if (!$t || $t['status'] === 'done') return pgi_err('Token cannot be cancelled');
		pgi_update_token($t['id'], ['status' => 'cancelled']); pgi_log('cancel', $t['token']);
		return pgi_done();
	}, pgi_perm('counter', 'doctor'));

	// ----- doctor rooms -----
	$to_room = function ($b, $t, $rm) {
		$doc = $t['doctor'] ?: null;
		if (!$doc && !empty($b['doctor'])) foreach (pgi_doctors() as $d) if ($d['id'] === (int) $b['doctor']) $doc = $d['id'];
		if (!$doc) foreach (pgi_doctors() as $d) if ($d['today'] && $d['todayRoom'] === (int) $rm['id']) { $doc = $d['id']; break; }
		pgi_update_token($t['id'], ['status' => 'room', 'room' => (int) $rm['id'], 'doctor' => $doc, 'room_at' => pgi_now()]);
		$call = pgi_set_call($t, 'room', $rm['no'], $rm['floor'] ?? null);
		pgi_log('call-to-room', $t['token'], 'Room ' . $rm['no']);
		return pgi_done(['token' => $t['token'], 'call' => $call]);
	};
	$route('room-next', 'POST', function ($b) use ($to_room) {
		global $wpdb;
		$s = pgi_settings(); $rm = pgi_room_of($s, $b['room'] ?? 0);
		if (!$rm) return pgi_err('Choose your room');
		$T = pgi_t('tokens'); $today = pgi_today();
		if (!empty($b['finishCurrent'])) { // "Done, call next" from the attendant phone
			$cur = $wpdb->get_row($wpdb->prepare("SELECT id, token FROM $T WHERE day=%s AND status='room' AND room=%d", $today, $rm['id']), ARRAY_A);
			if ($cur) { pgi_update_token($cur['id'], ['status' => 'done', 'done_at' => pgi_now()]); pgi_log('finish', $cur['token'], 'Room ' . $rm['no']); }
		}
		$busy = $wpdb->get_var($wpdb->prepare("SELECT token FROM $T WHERE day=%s AND status='room' AND room=%d", $today, $rm['id']));
		if ($busy) return pgi_err("Room {$rm['no']} is still with $busy. Finish it first.");
		// Patients sent to this room, or not yet given a room, of the room doctor's department (or of today's departments)
		$open = [];
		foreach (pgi_doctors() as $d) if ($d['today'] && $d['todayRoom'] === (int) $rm['id'] && $d['dept']) $open[] = $d['dept'];
		if (!$open) foreach (pgi_depts() as $d) if ($d['openToday']) $open[] = $d['id'];
		$open = array_unique(array_map('intval', $open));
		$t = pgi_int_fields($wpdb->get_row($wpdb->prepare("SELECT * FROM $T WHERE day=%s AND status='consult' AND (room=%d OR room IS NULL)" .
			($open ? ' AND dept IN (' . implode(',', $open) . ')' : '') . " ORDER BY priority DESC, (room IS NULL) ASC, registered_at ASC LIMIT 1", $today, $rm['id']), ARRAY_A), PGI_TOKEN_INTS);
		if (!$t) { if (!empty($b['finishCurrent'])) pgi_bump(); return pgi_err("No patient waiting for Room {$rm['no']}", 404); }
		return $to_room($b, $t, $rm);
	}, pgi_perm('doctor', 'ha'));
	$route('assign', 'POST', function ($b) use ($to_room) {
		$rm = pgi_room_of(pgi_settings(), $b['room'] ?? 0); $t = pgi_find_token($b['id'] ?? 0);
		if (!$t || $t['status'] !== 'consult' || !$rm) return pgi_err('Invalid token or room');
		return $to_room($b, $t, $rm);
	}, pgi_perm('doctor'));
	$route('finish', 'POST', function ($b) {
		$t = pgi_find_token($b['id'] ?? 0); if (!$t) return pgi_err('Token not found', 404);
		pgi_update_token($t['id'], ['status' => 'done', 'done_at' => pgi_now()]);
		$rm = $t['room'] ? pgi_room_of(pgi_settings(), $t['room']) : null;
		pgi_log('finish', $t['token'], $t['room'] ? 'Room ' . ($rm['no'] ?? $t['room']) : null);
		return pgi_done();
	}, pgi_perm('doctor', 'ha'));
	$route('checkin', 'POST', function ($b) {
		global $wpdb;
		$rm = pgi_room_of(pgi_settings(), $b['room'] ?? 0);
		$doc = $wpdb->get_row($wpdb->prepare("SELECT id, name FROM " . pgi_t('doctors') . " WHERE id=%d AND active=1", (int) ($b['doctor'] ?? 0)), ARRAY_A);
		if (!$doc || !$rm) return pgi_err('Choose your name and room');
		$C = pgi_t('checkins'); $today = pgi_today();
		$wpdb->query($wpdb->prepare("DELETE FROM $C WHERE day=%s AND (room=%d OR doctor=%d)", $today, $rm['id'], $doc['id'])); // one doctor per room
		$wpdb->insert($C, ['day' => $today, 'doctor' => (int) $doc['id'], 'room' => (int) $rm['id'], 'at' => pgi_now()]);
		pgi_log('doctor-checkin', null, 'Room ' . $rm['no'], $doc['name']);
		return pgi_done();
	}, pgi_perm('doctor'));
	$route('call-ha', 'POST', function ($b) {
		$rm = pgi_room_of(pgi_settings(), $b['room'] ?? 0); if (!$rm) return pgi_err('Choose your room');
		$h = pgi_ha_calls(); $h[$rm['id']] = pgi_now(); update_option('pgi_ha_calls', $h, true);
		pgi_log('call-attendant', null, 'Room ' . $rm['no']);
		pgi_push_ha_call($rm);
		return pgi_done();
	}, pgi_perm('doctor'));
	$route('ha-ack', 'POST', function ($b) {
		$rm = pgi_room_of(pgi_settings(), $b['room'] ?? 0); if (!$rm) return pgi_err('Choose your room');
		$h = pgi_ha_calls(); unset($h[$rm['id']]); update_option('pgi_ha_calls', $h, true);
		pgi_log('attendant-answered', null, 'Room ' . $rm['no']);
		return pgi_done();
	}, pgi_perm('ha', 'doctor'));

	// ----- admin -----
	$route('stats', 'GET', function ($b, $q) {
		global $wpdb;
		$day = preg_match('/^\d{4}-\d{2}-\d{2}$/', (string) $q->get_param('day')) ? $q->get_param('day') : pgi_today();
		$all = array_map(function ($t) { return pgi_int_fields($t, PGI_TOKEN_INTS); }, $wpdb->get_results($wpdb->prepare("SELECT * FROM " . pgi_t('tokens') . " WHERE day=%s", $day), ARRAY_A) ?: []);
		$mins = function ($a, $b) { return (strtotime($b) - strtotime($a)) / 60; };
		$avg = function ($xs) { return $xs ? round(array_sum($xs) / count($xs), 1) : 0; };
		$f = function ($cb) use ($all) { return array_values(array_filter($all, $cb)); };
		$byStatus = []; $hourly = array_fill(0, 24, 0);
		foreach ($all as $t) { $byStatus[$t['status']] = ($byStatus[$t['status']] ?? 0) + 1; $hourly[(int) wp_date('G', strtotime($t['created']))]++; }
		$byDept = [];
		foreach (pgi_depts() as $d) {
			$ts = array_values(array_filter($all, function ($t) use ($d) { return $t['dept'] === $d['id']; }));
			if (!$d['active'] && !$ts) continue;
			$byDept[] = ['id' => $d['id'], 'code' => $d['code'], 'name' => $d['name'], 'color' => $d['color'], 'total' => count($ts),
				'waiting' => count(array_filter($ts, function ($t) { return in_array($t['status'], ['waiting', 'called', 'consult'], true); })),
				'done' => count(array_filter($ts, function ($t) { return $t['status'] === 'done'; })),
				'avgWait' => $avg(array_map(function ($t) use ($mins) { return $mins($t['created'], $t['called_at']); }, array_filter($ts, function ($t) { return $t['called_at']; })))];
		}
		$byFloor = array_map(function ($fl) use ($all) {
			return ['floor' => $fl ?: 'Any', 'waiting' => count(array_filter($all, function ($t) use ($fl) { return $t['status'] === 'waiting' && $t['floor'] === $fl; })),
				'total' => count(array_filter($all, function ($t) use ($fl) { return $t['floor'] === $fl; }))];
		}, pgi_floors(pgi_settings()));
		return ['day' => $day, 'total' => count($all), 'byStatus' => (object) $byStatus, 'byDept' => $byDept, 'byFloor' => $byFloor, 'hourly' => $hourly,
			'emergency' => count($f(function ($t) { return $t['priority'] === 2; })), 'senior' => count($f(function ($t) { return $t['priority'] === 1; })),
			'avgWait' => $avg(array_map(function ($t) use ($mins) { return $mins($t['created'], $t['called_at']); }, $f(function ($t) { return $t['called_at']; }))),
			'avgConsult' => $avg(array_map(function ($t) use ($mins) { return $mins($t['room_at'], $t['done_at']); }, $f(function ($t) { return $t['room_at'] && $t['done_at']; }))),
			'avgTotal' => $avg(array_map(function ($t) use ($mins) { return $mins($t['created'], $t['done_at']); }, $f(function ($t) { return $t['done_at']; })))];
	}, pgi_perm());
	$dayp = function ($v, $d) { return preg_match('/^\d{4}-\d{2}-\d{2}$/', (string) $v) ? (string) $v : $d; };
	$route('tokens.csv', 'GET', function ($b, $q) use ($dayp) {
		global $wpdb;
		$s = pgi_settings(); $to = $dayp($q->get_param('to') ?: $q->get_param('day'), pgi_today()); $from = $dayp($q->get_param('from'), $to);
		$rows = array_map(function ($t) use ($s) {
			$rm = $t['room'] ? pgi_room_of($s, $t['room']) : null;
			return $t + ['room_no' => $rm['no'] ?? ($t['room'] ?: ''), 'priority_text' => PGI_PRIORITY[(int) $t['priority']] ?? ''];
		}, $wpdb->get_results($wpdb->prepare("SELECT t.*, d.name dept_name, doc.name doctor_name FROM " . pgi_t('tokens') . " t JOIN " . pgi_t('departments') . " d ON d.id=t.dept
			LEFT JOIN " . pgi_t('doctors') . " doc ON doc.id=t.doctor WHERE t.day BETWEEN %s AND %s ORDER BY t.day, t.id", $from, $to), ARRAY_A) ?: []);
		pgi_send_csv('tokens-' . ($from === $to ? $from : "{$from}_to_{$to}") . '.csv', ['day', 'token', 'dept_name', 'priority_text', 'status', 'name', 'phone', 'age', 'gender', 'floor', 'counter', 'doctor_name', 'room_no', 'created', 'called_at', 'registered_at', 'room_at', 'done_at', 'source'], $rows);
	}, pgi_perm());
	$route('audit', 'GET', function () { global $wpdb; return ['rows' => $wpdb->get_results("SELECT * FROM " . pgi_t('audit') . " ORDER BY id DESC LIMIT 500", ARRAY_A) ?: []]; }, pgi_perm());
	$route('audit.csv', 'GET', function () {
		global $wpdb;
		pgi_send_csv('audit-log.csv', ['ts', 'user', 'action', 'token', 'place', 'details'], $wpdb->get_results("SELECT * FROM " . pgi_t('audit') . " ORDER BY id DESC LIMIT 20000", ARRAY_A) ?: []);
	}, pgi_perm());
	$route('report', 'GET', function ($b, $q) use ($dayp) {
		global $wpdb;
		$T = pgi_t('tokens'); $to = $dayp($q->get_param('to'), pgi_today()); $from = $dayp($q->get_param('from'), $to);
		$rows = $wpdb->get_results($wpdb->prepare("SELECT day, COUNT(*) total, SUM(status='done') done, SUM(status='missed') missed, SUM(status='skipped') skipped, SUM(status='cancelled') cancelled,
			SUM(status IN ('waiting','called','consult','room')) open, SUM(priority=1) senior, SUM(priority=2) emergency
			FROM $T WHERE day BETWEEN %s AND %s GROUP BY day ORDER BY day DESC", $from, $to), ARRAY_A) ?: [];
		$waits = []; // minutes from token to counter call, per day
		foreach ($wpdb->get_results($wpdb->prepare("SELECT day, created, called_at FROM $T WHERE day BETWEEN %s AND %s AND called_at IS NOT NULL", $from, $to), ARRAY_A) ?: [] as $w)
			$waits[$w['day']][] = (strtotime($w['called_at']) - strtotime($w['created'])) / 60;
		$rows = array_map(function ($r) use ($waits) {
			foreach (['total', 'done', 'missed', 'skipped', 'cancelled', 'open', 'senior', 'emergency'] as $k) $r[$k] = (int) $r[$k];
			$m = $waits[$r['day']] ?? [];
			return $r + ['avgWait' => $m ? round(array_sum($m) / count($m), 1) : null];
		}, $rows);
		$missed = $wpdb->get_results($wpdb->prepare("SELECT t.day, t.token, t.name, t.phone, t.priority, d.name dept, t.updated FROM $T t JOIN " . pgi_t('departments') . " d ON d.id=t.dept
			WHERE t.day BETWEEN %s AND %s AND t.status='missed' ORDER BY t.day DESC, t.id LIMIT 1000", $from, $to), ARRAY_A) ?: [];
		return ['from' => $from, 'to' => $to, 'rows' => $rows, 'missed' => array_map(function ($x) { return pgi_int_fields($x, ['priority']); }, $missed)];
	}, pgi_perm());

	$route('settings', 'POST', function ($b) {
		$s = pgi_settings(); $p = $b['settings'] ?? [];
		foreach (['hospital', 'building', 'tagline', 'theme', 'character', 'langs', 'rate', 'toneCounter', 'toneRoom', 'avgServiceMinutes', 'kioskDetails', 'kioskEmergency', 'floorAssign', 'counters', 'rooms', 'voice', 'volume', 'repeat', 'styleEn', 'styleHi', 'patientNotes', 'scheduleUrl', 'displays', 'doctorBeep'] as $k)
			if (array_key_exists($k, $p)) $s[$k] = $p[$k];
		if (!in_array($s['theme'], ['teal', 'blue', 'green', 'purple', 'maroon', 'orange', 'contrast', 'night'], true)) $s['theme'] = 'teal';
		$s['hospital'] = pgi_clean($s['hospital'], 120) ?: PGI_HOSPITAL; $s['building'] = pgi_clean($s['building'], 80); $s['tagline'] = pgi_clean($s['tagline'], 80);
		$s['character'] = in_array($s['character'], ['nurse', 'male', 'doctor'], true) ? $s['character'] : 'nurse';
		$s['rate'] = pgi_clamp($s['rate'], 0.5, 1.5, 0.9);
		$s['avgServiceMinutes'] = (int) round(pgi_clamp($s['avgServiceMinutes'], 0, 60, 0));
		$s['floorAssign'] = $s['floorAssign'] === 'balance' ? 'balance' : 'none';
		$s['kioskDetails'] = !empty($s['kioskDetails']); $s['kioskEmergency'] = !empty($s['kioskEmergency']); $s['doctorBeep'] = $s['doctorBeep'] !== false;
		$voice = [];
		foreach ((array) $s['voice'] as $l => $v) if (preg_match('/^[a-z]{2}$/', $l)) $voice[$l] = ['name' => pgi_clean($v['name'] ?? '', 120), 'rate' => pgi_clamp($v['rate'] ?? null, 0.5, 1.5, 0.95), 'pitch' => pgi_clamp($v['pitch'] ?? null, 0.5, 2, 1)];
		$s['voice'] = $voice ?: new stdClass();
		$s['volume'] = pgi_clamp($s['volume'], 0.1, 1, 1); $s['repeat'] = (int) round(pgi_clamp($s['repeat'], 1, 5, 1));
		foreach (['styleEn', 'styleHi'] as $k) $s[$k] = in_array($s[$k], ['standard', 'short', 'polite'], true) ? $s[$k] : 'standard';
		foreach (['toneCounter', 'toneRoom'] as $k) $s[$k] = preg_match('/^[a-z]{1,10}$/', (string) $s[$k]) ? $s[$k] : 'soft';
		$s['langs'] = array_values(array_filter((array) $s['langs'], function ($l) { return is_string($l) && preg_match('/^[a-z]{2}$/', $l); })) ?: ['en'];
		$s['patientNotes'] = implode("\n", array_slice(array_values(array_filter(array_map(function ($l) { return mb_substr(trim($l), 0, 200); }, preg_split('/\r?\n/', str_replace(['<', '>'], '', (string) $s['patientNotes']))))), 0, 8));
		$s['scheduleUrl'] = preg_match('#^https?://[^\s"\'<>]+$#', trim((string) $s['scheduleUrl'])) ? mb_substr(trim($s['scheduleUrl']), 0, 300) : '';
		$disp = [];
		foreach ((array) $s['displays'] as $k => $v) if (preg_match('/^(hall:.{1,40}|room:\d+|counter|doctor)$/u', $k))
			$disp[pgi_clean($k, 50)] = ['audio' => ($v['audio'] ?? true) !== false, 'langs' => array_values(array_filter((array) ($v['langs'] ?? []), function ($l) { return is_string($l) && preg_match('/^[a-z]{2}$/', $l); })), 'repeat' => (int) round(pgi_clamp($v['repeat'] ?? 0, 0, 5, 0))];
		$s['displays'] = $disp ?: new stdClass();
		$seen = []; $counters = [];
		foreach ((array) $s['counters'] as $c) { $no = (int) round((float) ($c['no'] ?? 0)); if ($no >= 1 && $no <= 99 && !isset($seen[$no])) { $seen[$no] = 1; $counters[] = ['no' => $no, 'floor' => pgi_clean($c['floor'] ?? '', 30)]; } }
		usort($counters, function ($a, $b) { return $a['no'] - $b['no']; });
		if (!$counters) return pgi_err('Add at least one counter');
		$s['counters'] = $counters;
		// Rooms keep their id so doctors and tokens stay linked when a room number is renamed
		$old = pgi_settings()['rooms']; $max = 0; foreach ($old as $r) $max = max($max, (int) $r['id']); foreach ((array) $s['rooms'] as $r) $max = max($max, (int) ($r['id'] ?? 0));
		$rooms = []; $nos = [];
		foreach ((array) $s['rooms'] as $r) { $no = pgi_clean($r['no'] ?? '', 12); if ($no === '') continue; $rooms[] = ['id' => (int) ($r['id'] ?? 0) ?: ++$max, 'no' => $no, 'floor' => pgi_clean($r['floor'] ?? '', 30)]; $nos[] = $no; }
		if (!$rooms) return pgi_err('Add at least one room');
		if (count(array_unique($nos)) !== count($nos)) return pgi_err('Two rooms have the same number');
		$s['rooms'] = $rooms;
		pgi_save_settings($s); pgi_log('settings-update');
		return pgi_done();
	}, pgi_perm());
	$route('logo', 'POST', function ($b) {
		$s = pgi_settings(); $up = wp_upload_dir(); $dir = trailingslashit($up['basedir']) . 'pgi-token';
		wp_mkdir_p($dir);
		foreach (['png', 'jpg', 'webp'] as $e) @unlink("$dir/logo.$e");
		if (!empty($b['remove'])) $s['logo'] = '';
		else {
			if (!preg_match('#^data:image/(png|jpeg|webp);base64,([A-Za-z0-9+/=]+)$#', (string) ($b['dataUrl'] ?? ''), $m)) return pgi_err('Please choose a PNG, JPG or WEBP image');
			$ext = ['png' => 'png', 'jpeg' => 'jpg', 'webp' => 'webp'][$m[1]]; $bin = base64_decode($m[2]);
			if (strlen($bin) > 3 * 1024 * 1024) return pgi_err('Logo must be smaller than 3 MB');
			if (!@getimagesizefromstring($bin)) return pgi_err('That file is not a valid image');
			file_put_contents("$dir/logo.$ext", $bin);
			$s['logo'] = trailingslashit($up['baseurl']) . "pgi-token/logo.$ext?v=" . time();
		}
		pgi_save_settings($s); pgi_log(!empty($b['remove']) ? 'logo-remove' : 'logo-upload');
		return pgi_done(['logo' => $s['logo']]);
	}, pgi_perm());
	$route('departments', 'POST', function ($d) {
		global $wpdb;
		$code = strtoupper(pgi_clean($d['code'] ?? '', 2)); $name = pgi_clean($d['name'] ?? '');
		if (!preg_match('/^[A-Z]{1,2}$/', $code) || !$name) return pgi_err('Code (1-2 letters) and name are required');
		$row = ['code' => $code, 'name' => $name, 'name_local' => pgi_clean($d['name_local'] ?? ''), 'color' => preg_match('/^#[0-9a-fA-F]{3,8}$/', $d['color'] ?? '') ? $d['color'] : '#0f766e',
			'days' => pgi_days_param($d['days'] ?? ''), 'location' => pgi_clean($d['location'] ?? '', 80)];
		$dup = $wpdb->get_var($wpdb->prepare("SELECT id FROM " . pgi_t('departments') . " WHERE code=%s AND id<>%d", $code, (int) ($d['id'] ?? 0)));
		if ($dup) return pgi_err('That code is already used by another department');
		if (!empty($d['id'])) $wpdb->update(pgi_t('departments'), $row + ['active' => !empty($d['active']) ? 1 : 0, 'sort' => (int) ($d['sort'] ?? 0)], ['id' => (int) $d['id']]);
		else $wpdb->insert(pgi_t('departments'), $row + ['active' => ($d['active'] ?? true) === false ? 0 : 1, 'sort' => (int) ($d['sort'] ?? 99)]);
		pgi_log(!empty($d['id']) ? 'department-update' : 'department-add', null, null, "$code $name");
		return pgi_done();
	}, pgi_perm());
	$route('doctors', 'POST', function ($d) {
		global $wpdb;
		$s = pgi_settings(); $D = pgi_t('doctors');
		if (!empty($d['delete']) && !empty($d['id'])) { $wpdb->delete($D, ['id' => (int) $d['id']]); pgi_log('doctor-delete', null, null, (string) $d['id']); return pgi_done(); }
		$name = pgi_clean(preg_replace('/^dr\.?\s+/i', '', (string) ($d['name'] ?? '')), 60);
		if (!$name) return pgi_err('Doctor name is required');
		$rm = pgi_room_of($s, $d['room'] ?? 0);
		$type = null; foreach (pgi_doctor_types() as $t) if ($t['id'] === (int) ($d['type'] ?? 0)) $type = $t['id'];
		$row = ['name' => $name, 'dept' => (int) ($d['dept'] ?? 0) ?: null, 'room' => $rm ? (int) $rm['id'] : null, 'days' => pgi_days_param($d['days'] ?? ''), 'type' => $type];
		if (!empty($d['id'])) $wpdb->update($D, $row + ['active' => !empty($d['active']) ? 1 : 0], ['id' => (int) $d['id']]);
		else $wpdb->insert($D, $row + ['active' => 1]);
		pgi_log(!empty($d['id']) ? 'doctor-update' : 'doctor-add', null, $rm ? 'Room ' . $rm['no'] : null, $name);
		return pgi_done();
	}, pgi_perm());
	$route('doctor-room', 'POST', function ($b) {
		global $wpdb;
		$doc = $wpdb->get_row($wpdb->prepare("SELECT id, name FROM " . pgi_t('doctors') . " WHERE id=%d", (int) ($b['id'] ?? 0)), ARRAY_A);
		if (!$doc) return pgi_err('Doctor not found', 404);
		$rm = !empty($b['room']) ? pgi_room_of(pgi_settings(), $b['room']) : null;
		$wpdb->update(pgi_t('doctors'), ['room' => $rm ? (int) $rm['id'] : null], ['id' => (int) $doc['id']]);
		pgi_log('doctor-room', null, $rm ? 'Room ' . $rm['no'] : null, $doc['name']);
		return pgi_done();
	}, pgi_perm());
	$route('doctor-types', 'POST', function ($d) {
		global $wpdb;
		$T = pgi_t('doctor_types');
		if (!empty($d['delete']) && !empty($d['id'])) { $wpdb->update(pgi_t('doctors'), ['type' => null], ['type' => (int) $d['id']]); $wpdb->delete($T, ['id' => (int) $d['id']]); }
		else {
			$name = pgi_clean($d['name'] ?? '', 40); if (!$name) return pgi_err('Type name is required');
			if (!empty($d['id'])) $wpdb->update($T, ['name' => $name, 'active' => ($d['active'] ?? true) === false ? 0 : 1], ['id' => (int) $d['id']]);
			else $wpdb->insert($T, ['name' => $name, 'active' => 1, 'sort' => (int) $wpdb->get_var("SELECT MAX(sort) FROM $T") + 1]);
		}
		pgi_log('doctor-type', null, null, pgi_clean($d['name'] ?? '', 40) ?: (string) ($d['id'] ?? ''));
		return pgi_done();
	}, pgi_perm());
	// Passwords for the staff accounts made in the setup wizard (admin = the signed-in admin)
	$route('passwords', 'POST', function ($b) {
		$pw = (array) ($b['passwords'] ?? []); $staff = (array) get_option('pgi_staff_users', []);
		foreach ($pw as $p) if ($p && strlen((string) $p) < 8) return pgi_err('Passwords must be at least 8 characters');
		$changed = [];
		foreach ($pw as $role => $p) {
			if (!$p) continue;
			$uid = $role === 'admin' ? get_current_user_id() : (int) ($staff[$role] ?? 0);
			if ($uid) { wp_set_password((string) $p, $uid); $changed[] = $role; }
		}
		pgi_log('password-update', null, null, implode(',', $changed));
		if (in_array('admin', $changed, true)) { wp_set_auth_cookie(get_current_user_id()); } // keep the admin signed in
		return pgi_ok(['changed' => $changed]);
	}, pgi_perm());

	// ----- push notifications -----
	$route('push-subscribe', 'POST', 'pgi_push_subscribe', $pub);
	$route('push-unsubscribe', 'POST', 'pgi_push_unsubscribe', $pub);
	$route('push-test', 'POST', 'pgi_push_test', $pub);
});

// Times are kept in UTC. Some databases hand them back as "2026-10-15 09:30:00"; send them to the screens as ISO "2026-10-15T09:30:00Z".
function pgi_iso_walk($v) {
	if (is_array($v)) return array_map('pgi_iso_walk', $v);
	if (is_string($v) && strlen($v) === 19 && preg_match('/^\d{4}-\d\d-\d\d \d\d:\d\d:\d\d$/', $v)) return str_replace(' ', 'T', $v) . 'Z';
	return $v;
}
add_filter('rest_post_dispatch', function ($res, $server, $req) {
	if (strpos($req->get_route(), '/pgi-token/v1/') === 0 && $res instanceof WP_REST_Response) $res->set_data(pgi_iso_walk($res->get_data()));
	return $res;
}, 10, 3);
