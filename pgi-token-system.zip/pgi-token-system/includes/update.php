<?php
if (!defined('ABSPATH')) exit;

/*
 * Updates from GitHub (or any web address).
 * WordPress checks the source twice a day, shows "Update available" on the Plugins page and in
 * PGI Token → Updates, and installs the new version with one click (WordPress's own updater).
 *
 * Source can be:
 *   - a public GitHub repository "owner/name": the latest Release is used (its pgi-token-system.zip
 *     asset, or the release's source code when no zip is attached), or
 *   - an https link to a JSON file: {"version":"3.1.0","download_url":"https://…/pgi-token-system.zip","notes":"…"}
 */

define('PGI_PLUGIN_FILE', 'pgi-token-system/pgi-token-system.php');

function pgi_update_source() { return trim((string) get_option('pgi_update_source', '')); }

// Latest version info, cached for 6 hours. Returns array or WP_Error.
function pgi_update_info($force = false) {
	$src = pgi_update_source();
	if ($src === '') return new WP_Error('pgi_no_source', 'No update source is set yet.');
	$key = 'pgi_update_' . md5($src);
	if (!$force && ($c = get_site_transient($key)) !== false) return $c;
	$info = preg_match('#^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$#', $src) ? pgi_update_from_github($src) : pgi_update_from_json($src);
	set_site_transient($key, $info, is_wp_error($info) ? 30 * MINUTE_IN_SECONDS : 6 * HOUR_IN_SECONDS);
	update_option('pgi_update_checked', time(), false);
	return $info;
}

function pgi_update_get($url, $accept = 'application/json') {
	$r = wp_remote_get($url, ['timeout' => 15, 'headers' => ['Accept' => $accept, 'User-Agent' => 'PGI-Token-System/' . PGI_VERSION]]);
	if (is_wp_error($r)) return new WP_Error('pgi_net', 'Could not reach the update server: ' . $r->get_error_message());
	$code = (int) wp_remote_retrieve_response_code($r);
	if ($code === 404) return new WP_Error('pgi_404', 'Nothing found at the update source. Check the repository name, that it is public, and that it has a published release.');
	if ($code !== 200) return new WP_Error('pgi_http', "The update server answered with error $code.");
	$j = json_decode(wp_remote_retrieve_body($r), true);
	return is_array($j) ? $j : new WP_Error('pgi_json', 'The update source did not return valid information.');
}

function pgi_update_from_github($repo) {
	$j = pgi_update_get("https://api.github.com/repos/$repo/releases/latest", 'application/vnd.github+json');
	if (is_wp_error($j)) return $j;
	$pkg = '';
	foreach ($j['assets'] ?? [] as $a) if (preg_match('/\.zip$/i', $a['name'] ?? '')) { $pkg = $a['browser_download_url']; break; }
	if (!$pkg) $pkg = $j['zipball_url'] ?? '';
	$v = ltrim((string) ($j['tag_name'] ?? ''), 'vV');
	if (!$v || !$pkg) return new WP_Error('pgi_release', 'The latest GitHub release has no version tag (like v3.1.0) or no download.');
	return ['version' => $v, 'package' => $pkg, 'notes' => (string) ($j['body'] ?? ''), 'url' => (string) ($j['html_url'] ?? "https://github.com/$repo"), 'date' => (string) ($j['published_at'] ?? '')];
}

function pgi_update_from_json($url) {
	if (strpos($url, 'https://') !== 0 && strpos($url, 'http://') !== 0) return new WP_Error('pgi_src', 'Enter a GitHub repository like owner/name, or a link starting with https://');
	$j = pgi_update_get($url);
	if (is_wp_error($j)) return $j;
	$v = ltrim((string) ($j['version'] ?? ''), 'vV'); $pkg = (string) ($j['download_url'] ?? '');
	if (!$v || !$pkg) return new WP_Error('pgi_json', 'The update file needs "version" and "download_url".');
	return ['version' => $v, 'package' => $pkg, 'notes' => (string) ($j['notes'] ?? ''), 'url' => (string) ($j['homepage'] ?? $url), 'date' => (string) ($j['date'] ?? '')];
}

function pgi_update_available() {
	$i = pgi_update_info();
	return !is_wp_error($i) && version_compare($i['version'], PGI_VERSION, '>') ? $i : null;
}

// Tell WordPress about the new version (Plugins page, Dashboard → Updates, auto-updates)
add_filter('pre_set_site_transient_update_plugins', function ($t) {
	if (!is_object($t) || pgi_update_source() === '') return $t;
	$i = pgi_update_info();
	if (is_wp_error($i)) return $t;
	$item = (object) ['id' => PGI_PLUGIN_FILE, 'slug' => 'pgi-token-system', 'plugin' => PGI_PLUGIN_FILE, 'new_version' => $i['version'], 'url' => $i['url'],
		'package' => $i['package'], 'requires_php' => '7.4', 'icons' => ['1x' => PGI_URL . 'app/icon-192.png']];
	if (version_compare($i['version'], PGI_VERSION, '>')) { $t->response[PGI_PLUGIN_FILE] = $item; unset($t->no_update[PGI_PLUGIN_FILE]); }
	else { $t->no_update[PGI_PLUGIN_FILE] = $item; unset($t->response[PGI_PLUGIN_FILE]); }
	return $t;
});

// "View details" window on the Plugins page
add_filter('plugins_api', function ($res, $action, $args) {
	if ($action !== 'plugin_information' || ($args->slug ?? '') !== 'pgi-token-system') return $res;
	$i = pgi_update_info();
	if (is_wp_error($i)) return $res;
	return (object) ['name' => 'PGI Token System', 'slug' => 'pgi-token-system', 'version' => $i['version'], 'author' => 'ANS Token System', 'homepage' => $i['url'],
		'requires_php' => '7.4', 'last_updated' => $i['date'], 'download_link' => $i['package'],
		'sections' => ['changelog' => wpautop(esc_html($i['notes'] ?: 'Version ' . $i['version']))]];
}, 10, 3);

// GitHub source-code zips unpack to "owner-repo-abc123/"; rename to the plugin folder so the update replaces this plugin
add_filter('upgrader_source_selection', function ($source, $remote, $upgrader, $extra = []) {
	global $wp_filesystem;
	if (($extra['plugin'] ?? '') !== PGI_PLUGIN_FILE) return $source;
	if (!file_exists(trailingslashit($source) . 'pgi-token-system.php')) {
		// the plugin may sit one level down inside the zip
		foreach ((array) glob(trailingslashit($source) . '*/pgi-token-system.php') as $f) { $source = trailingslashit(dirname($f)); break; }
		if (!file_exists(trailingslashit($source) . 'pgi-token-system.php')) return new WP_Error('pgi_pkg', 'The downloaded file is not the PGI Token System plugin.');
	}
	$want = trailingslashit($remote) . 'pgi-token-system/';
	if (untrailingslashit($source) !== untrailingslashit($want) && $wp_filesystem->move($source, $want, true)) return $want;
	return $source;
}, 10, 4);

add_action('upgrader_process_complete', function () { delete_site_transient('pgi_update_' . md5(pgi_update_source())); });

// ---------- PGI Token → Updates page ----------
add_action('admin_menu', function () {
	$n = current_user_can('update_plugins') && pgi_update_source() !== '' && pgi_update_available() ? ' <span class="update-plugins count-1"><span class="plugin-count">1</span></span>' : '';
	add_submenu_page('pgi-token', 'Updates', 'Updates' . $n, 'update_plugins', 'pgi-updates', 'pgi_updates_page');
}, 20);

add_action('admin_post_pgi_updates', function () {
	if (!current_user_can('update_plugins')) wp_die('Not allowed');
	check_admin_referer('pgi_updates');
	$src = trim(sanitize_text_field(wp_unslash($_POST['source'] ?? '')));
	$src = preg_replace('#^https?://github\.com/([^/]+/[^/]+?)(\.git)?/?$#', '$1', $src); // a pasted GitHub link works too
	update_option('pgi_update_source', $src, false);
	if ($src !== '') { pgi_update_info(true); delete_site_transient('update_plugins'); wp_update_plugins(); }
	wp_safe_redirect(admin_url('admin.php?page=pgi-updates&checked=1'));
	exit;
});

function pgi_updates_page() {
	$src = pgi_update_source(); $i = $src !== '' ? pgi_update_info() : null; $checked = (int) get_option('pgi_update_checked', 0);
	$new = $i && !is_wp_error($i) && version_compare($i['version'], PGI_VERSION, '>');
	$upd = wp_nonce_url(self_admin_url('update.php?action=upgrade-plugin&plugin=' . rawurlencode(PGI_PLUGIN_FILE)), 'upgrade-plugin_' . PGI_PLUGIN_FILE);
	?>
	<style>
	.pgi-up{max-width:720px;margin:24px auto}.pgi-up .box{background:#fff;border:1px solid #dcdcde;border-radius:14px;padding:26px 30px;margin-bottom:18px;box-shadow:0 8px 30px rgba(0,0,0,.05)}
	.pgi-up h1{font-size:23px;margin:0 0 4px}.pgi-up .ver{display:flex;gap:28px;margin:16px 0}.pgi-up .ver b{display:block;font-size:26px}.pgi-up .ver span{color:#646970}
	.pgi-up .new{border-left:5px solid #0f766e;background:#f0fdfa}.pgi-up .ok{color:#059669;font-weight:600}.pgi-up .err{color:#b45309;font-weight:600}
	.pgi-up pre{white-space:pre-wrap;background:#f6f7f7;border-radius:8px;padding:12px;max-height:260px;overflow:auto;font:13px/1.5 inherit}
	.pgi-up input[type=text]{width:100%;padding:6px 10px;border-radius:8px}
	</style>
	<div class="wrap pgi-up">
	<div class="box <?php echo $new ? 'new' : ''; ?>">
		<h1>PGI Token System updates</h1>
		<div class="ver"><div><span>Installed</span><b><?php echo esc_html(PGI_VERSION); ?></b></div>
		<?php if ($i && !is_wp_error($i)) { ?><div><span>Latest</span><b><?php echo esc_html($i['version']); ?></b></div><?php } ?></div>
		<?php if ($src === '') { ?>
			<p>Set where new versions are published below, then press <b>Save and check now</b>.</p>
		<?php } elseif (is_wp_error($i)) { ?>
			<p class="err"><?php echo esc_html($i->get_error_message()); ?></p>
		<?php } elseif ($new) { ?>
			<p><b>Version <?php echo esc_html($i['version']); ?> is available.</b> Your tokens, doctors, settings and logins are kept. Screens reload by themselves after the update.</p>
			<?php if ($i['notes']) echo '<pre>' . esc_html($i['notes']) . '</pre>'; ?>
			<p><a class="button button-primary button-hero" href="<?php echo esc_url($upd); ?>">Update now</a></p>
		<?php } else { ?>
			<p class="ok">✓ You have the latest version.</p>
		<?php } ?>
		<?php if ($checked) echo '<p class="description">Last checked ' . esc_html(human_time_diff($checked)) . ' ago. WordPress also checks by itself twice a day.</p>'; ?>
	</div>
	<form class="box" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
		<input type="hidden" name="action" value="pgi_updates"><?php wp_nonce_field('pgi_updates'); ?>
		<h2 style="margin-top:0">Update source</h2>
		<p><label for="pgiSrc"><b>GitHub repository</b> (like <code>your-name/pgi-token-system</code>) <b>or</b> a link to an update file</label></p>
		<input type="text" id="pgiSrc" name="source" value="<?php echo esc_attr($src); ?>" placeholder="your-name/pgi-token-system">
		<p class="description">The repository must be public. It holds only the program; no patient data or passwords are ever in it.</p>
		<p><button class="button button-primary">Save and check now</button></p>
	</form>
	</div>
	<?php
}
