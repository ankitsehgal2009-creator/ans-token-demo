<?php
if (!defined('ABSPATH')) exit;

/*
 * First-run installation wizard (opens right after the plugin is activated) and the
 * "PGI Token" menu in the WordPress dashboard.
 */

add_action('admin_init', function () {
	if (get_transient('pgi_redirect_setup') && current_user_can('manage_options') && !wp_doing_ajax() && !isset($_GET['activate-multi'])) {
		delete_transient('pgi_redirect_setup');
		wp_safe_redirect(admin_url('admin.php?page=pgi-setup'));
		exit;
	}
});

add_action('admin_menu', function () {
	add_menu_page('PGI Token System', 'PGI Token', 'manage_options', 'pgi-token', 'pgi_admin_home', 'dashicons-tickets-alt', 26);
	add_submenu_page('pgi-token', 'Open the app', 'Open the app', 'manage_options', 'pgi-token', 'pgi_admin_home');
	add_submenu_page('pgi-token', 'Setup wizard', 'Setup wizard', 'manage_options', 'pgi-setup', 'pgi_setup_page');
});

add_action('admin_notices', function () {
	if (get_option('pgi_setup_done') || !current_user_can('manage_options') || (($_GET['page'] ?? '') === 'pgi-setup')) return;
	echo '<div class="notice notice-warning"><p><b>PGI Token System</b> is installed but not set up yet. <a class="button button-primary" href="' . esc_url(admin_url('admin.php?page=pgi-setup')) . '">Run the setup</a></p></div>';
});

// Saves the wizard
add_action('admin_post_pgi_setup', function () {
	if (!current_user_can('manage_options')) wp_die('Not allowed');
	check_admin_referer('pgi_setup');
	$in = wp_unslash($_POST);
	$errors = [];

	// 1. Hospital
	$s = pgi_settings();
	$s['hospital'] = pgi_clean($in['hospital'] ?? '', 120) ?: PGI_HOSPITAL;
	$s['building'] = pgi_clean($in['building'] ?? '', 80);
	$s['theme'] = preg_match('/^[a-z]+$/', $in['theme'] ?? '') ? $in['theme'] : 'teal';

	// 2. Counters and rooms
	$g = (int) pgi_clamp($in['counters_ground'] ?? 3, 0, 20, 3); $f = (int) pgi_clamp($in['counters_first'] ?? 3, 0, 20, 3);
	if ($g + $f < 1) $g = 1;
	$s['counters'] = [];
	for ($i = 1; $i <= $g + $f; $i++) $s['counters'][] = ['no' => $i, 'floor' => $i <= $g ? 'Ground Floor' : 'First Floor'];
	$n = (int) pgi_clamp($in['rooms'] ?? 4, 1, 60, 4); $rf = pgi_clean($in['rooms_floor'] ?? 'First Floor', 40) ?: 'First Floor';
	$old = []; foreach ($s['rooms'] as $r) $old[(int) $r['id']] = $r;
	$s['rooms'] = [];
	for ($i = 1; $i <= $n; $i++) $s['rooms'][] = ['id' => $i, 'no' => $old[$i]['no'] ?? (string) $i, 'floor' => $rf];
	pgi_save_settings($s);

	// 3. Departments and doctors
	pgi_install_tables(); pgi_add_roles();
	pgi_seed(!empty($in['load_doctors']));

	// 4. Staff accounts
	$staff = get_option('pgi_staff_users', []); if (!is_array($staff)) $staff = [];
	foreach (['admin' => 'pgi_admin', 'counter' => 'pgi_counter', 'doctor' => 'pgi_doctor', 'ha' => 'pgi_ha'] as $key => $role) {
		$login = sanitize_user($in["user_$key"] ?? '', true); $pass = (string) ($in["pass_$key"] ?? '');
		if ($login === '') continue;
		$u = get_user_by('login', $login);
		if ($pass !== '' && strlen($pass) < 8) { $errors[] = "Password for “{$login}” must be at least 8 characters."; continue; }
		if (!$u) {
			if ($pass === '') { $errors[] = "Enter a password for the new account “{$login}”."; continue; }
			$id = wp_insert_user(['user_login' => $login, 'user_pass' => $pass, 'role' => $role, 'display_name' => $login,
				'user_email' => $login . '.' . wp_generate_password(6, false) . '@token.invalid']);
			if (is_wp_error($id)) { $errors[] = $id->get_error_message(); continue; }
		} else {
			$id = $u->ID;
			if (!in_array('administrator', (array) $u->roles, true)) $u->add_role($role);
			if ($pass !== '') wp_set_password($pass, $id);
		}
		$staff[$key] = (int) $id;
	}
	update_option('pgi_staff_users', $staff, false);

	// 5. Pretty links (needed for /token/), push keys, done
	if (!get_option('permalink_structure')) update_option('permalink_structure', '/%postname%/');
	pgi_app_rewrite(); flush_rewrite_rules();
	pgi_vapid();
	update_option('pgi_setup_done', gmdate('c'), false);
	pgi_bump();
	set_transient('pgi_setup_errors', $errors, 300);
	wp_safe_redirect(admin_url('admin.php?page=pgi-setup&done=1'));
	exit;
});

function pgi_checks() {
	$https = is_ssl() || strpos(home_url(), 'https://') === 0;
	return [
		['PHP 7.4 or newer', version_compare(PHP_VERSION, '7.4', '>='), 'PHP ' . PHP_VERSION],
		['Secure site (https)', $https, $https ? 'OK' : 'Phones only install the app and show alerts on an https site. Ask your web host to turn on SSL.'],
		['Push notifications (OpenSSL)', pgi_push_ready(), pgi_push_ready() ? 'OK' : 'The PHP OpenSSL extension is missing, so phone alerts will be off. Everything else works.'],
		['Database', true, 'Tables are created in this WordPress database'],
	];
}

function pgi_links() {
	$b = home_url('/' . PGI_SLUG . '/');
	return [['Home (all screens)', $b], ['Token kiosk', $b . 'kiosk.html'], ['Hall TV display', $b . 'display.html'], ['Registration counter', $b . 'counter.html'],
		['Doctor desk', $b . 'doctor.html'], ['Room attendant (phone)', $b . 'ha.html'], ['Admin dashboard', $b . 'admin.html']];
}

function pgi_admin_home() {
	echo '<div class="wrap"><h1>PGI Token System</h1>';
	if (!get_option('pgi_setup_done')) echo '<p><a class="button button-primary button-hero" href="' . esc_url(admin_url('admin.php?page=pgi-setup')) . '">Run the setup</a></p>';
	echo '<p>Open these on the kiosk, TVs, counter computers and phones. On a phone, open the page and choose <b>Add to Home Screen</b> (iPhone) or <b>Install app</b> (Android).</p><table class="widefat striped" style="max-width:720px"><tbody>';
	foreach (pgi_links() as [$n, $u]) echo '<tr><td><b>' . esc_html($n) . '</b></td><td><a href="' . esc_url($u) . '" target="_blank">' . esc_html($u) . '</a></td></tr>';
	echo '</tbody></table><p style="margin-top:16px"><a class="button" href="' . esc_url(admin_url('admin.php?page=pgi-setup')) . '">Run setup again</a></p></div>';
}

function pgi_setup_page() {
	if (!current_user_can('manage_options')) return;
	$s = pgi_settings(); $staff = get_option('pgi_staff_users', []);
	$login = function ($k, $def) use ($staff) { $u = !empty($staff[$k]) ? get_userdata($staff[$k]) : null; return $u ? $u->user_login : $def; };
	$counts = array_count_values(array_map(function ($c) { return $c['floor'] ?? ''; }, $s['counters']));
	?>
	<style>
	.pgi-wiz{max-width:760px;margin:24px auto;font-size:14px}
	.pgi-wiz .box{background:#fff;border:1px solid #dcdcde;border-radius:14px;padding:28px 32px;box-shadow:0 8px 30px rgba(0,0,0,.05)}
	.pgi-wiz h1{display:flex;align-items:center;gap:12px;font-size:24px;margin:0 0 6px}
	.pgi-wiz h1 i{width:40px;height:40px;border-radius:11px;background:linear-gradient(135deg,#14b8a6,#0f766e);display:grid;place-items:center;color:#fff;font-style:normal;font-size:26px;font-weight:700}
	.pgi-steps{display:flex;gap:6px;margin:18px 0 24px;counter-reset:s}
	.pgi-steps span{flex:1;padding:8px 6px;border-radius:9px;background:#f0f0f1;color:#646970;text-align:center;font-weight:600;font-size:12px}
	.pgi-steps span.on{background:#0f766e;color:#fff}.pgi-steps span.ok{background:#d1fae5;color:#065f46}
	.pgi-step{display:none}.pgi-step.on{display:block;animation:pgiIn .25s ease}
	@keyframes pgiIn{from{opacity:0;transform:translateY(6px)}}
	.pgi-step h2{font-size:18px;margin:0 0 6px}.pgi-step p.d{color:#646970;margin:0 0 18px}
	.pgi-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px 18px}.pgi-grid label{display:grid;gap:5px;font-weight:600}.pgi-grid .full{grid-column:1/-1}
	.pgi-grid input[type=text],.pgi-grid input[type=password],.pgi-grid input[type=number],.pgi-grid select{width:100%;padding:6px 10px;border-radius:8px}
	.pgi-nav [hidden]{display:none!important}.pgi-nav{display:flex;justify-content:space-between;margin-top:26px;padding-top:18px;border-top:1px solid #f0f0f1}
	.pgi-check{display:grid;grid-template-columns:26px 1fr;gap:8px;padding:10px 0;border-bottom:1px solid #f0f0f1}.pgi-check b{display:block}
	.pgi-check .y{color:#059669;font-weight:700}.pgi-check .n{color:#d97706;font-weight:700}
	.pgi-staff{width:100%;border-collapse:collapse}.pgi-staff td,.pgi-staff th{padding:8px 6px;text-align:left;border-bottom:1px solid #f0f0f1}.pgi-staff input{width:100%}
	.pgi-links a{display:flex;justify-content:space-between;padding:10px 12px;border:1px solid #dcdcde;border-radius:9px;margin-bottom:8px;text-decoration:none;font-weight:600}
	.pgi-links a span{color:#646970;font-weight:400}
	.pgi-done{text-align:center}.pgi-done .big{font-size:54px;line-height:1;margin:8px 0}
	.pgi-qr{display:flex;gap:20px;justify-content:center;flex-wrap:wrap;margin:16px 0}.pgi-qr div{text-align:center;font-weight:600}.pgi-qr svg{width:150px;height:150px;display:block}
	@media(max-width:700px){.pgi-grid{grid-template-columns:1fr}.pgi-wiz .box{padding:20px}}
	</style>
	<div class="wrap pgi-wiz"><div class="box">
	<h1><i>+</i> PGI Token System setup</h1>
	<?php if (isset($_GET['done'])) { $errs = get_transient('pgi_setup_errors') ?: []; delete_transient('pgi_setup_errors'); ?>
		<div class="pgi-done"><div class="big">🎉</div><h2>Setup complete</h2><p>The token system is ready. Open the screens below on each device.</p></div>
		<?php foreach ($errs as $e) echo '<div class="notice notice-error inline"><p>' . esc_html($e) . '</p></div>'; ?>
		<div class="pgi-qr"><div><span id="q1"></span>Attendant phone app</div><div><span id="q2"></span>Doctor desk</div><div><span id="q3"></span>Home</div></div>
		<div class="pgi-links"><?php foreach (pgi_links() as [$n, $u]) echo '<a href="' . esc_url($u) . '" target="_blank">' . esc_html($n) . '<span>' . esc_html(wp_make_link_relative($u)) . ' ↗</span></a>'; ?></div>
		<p class="d" style="color:#646970">Staff sign in on the screens with the accounts you just set. Patients scan the QR on their slip and can tap <b>Turn on alerts</b> to be notified when called.</p>
		<p><a class="button" href="<?php echo esc_url(admin_url('admin.php?page=pgi-setup')); ?>">Run setup again</a></p>
		<script src="<?php echo esc_url(PGI_URL . 'app/qrcode.js'); ?>"></script>
		<script>[['q1', <?php echo wp_json_encode(home_url('/' . PGI_SLUG . '/ha.html')); ?>], ['q2', <?php echo wp_json_encode(home_url('/' . PGI_SLUG . '/doctor.html')); ?>], ['q3', <?php echo wp_json_encode(home_url('/' . PGI_SLUG . '/')); ?>]]
			.forEach(([id, u]) => { const q = qrcode(0, 'M'); q.addData(u); q.make(); document.getElementById(id).innerHTML = q.createSvgTag({ cellSize: 4, margin: 2, scalable: true }); });</script>
	<?php } else { ?>
	<div class="pgi-steps" id="pgiSteps"><span>1 Check</span><span>2 Hospital</span><span>3 Counters &amp; rooms</span><span>4 Doctors</span><span>5 Staff logins</span></div>
	<form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" id="pgiForm" autocomplete="off">
		<input type="hidden" name="action" value="pgi_setup"><?php wp_nonce_field('pgi_setup'); ?>

		<section class="pgi-step">
			<h2>Welcome</h2><p class="d">This sets up the token system on this website: the database tables, the hospital details, staff logins and phone alerts. All patient and token records are saved in this WordPress database.</p>
			<?php foreach (pgi_checks() as [$n, $ok, $msg]) echo '<div class="pgi-check"><span class="' . ($ok ? 'y' : 'n') . '">' . ($ok ? '✓' : '!') . '</span><div><b>' . esc_html($n) . '</b>' . esc_html($msg) . '</div></div>'; ?>
		</section>

		<section class="pgi-step">
			<h2>Hospital</h2><p class="d">Shown on every screen, the token slip and the phone app.</p>
			<div class="pgi-grid">
				<label class="full">Hospital name<input type="text" name="hospital" value="<?php echo esc_attr($s['hospital']); ?>" required></label>
				<label>Building / block<input type="text" name="building" value="<?php echo esc_attr($s['building'] ?: 'Advanced Neurosciences Centre'); ?>"></label>
				<label>Colour theme<select name="theme"><?php foreach (['teal' => 'Teal', 'blue' => 'Blue', 'green' => 'Green', 'purple' => 'Purple', 'maroon' => 'Maroon', 'orange' => 'Orange', 'contrast' => 'High contrast', 'night' => 'Night (dark)'] as $k => $n) echo '<option value="' . $k . '"' . selected($s['theme'], $k, false) . '>' . $n . '</option>'; ?></select></label>
			</div>
		</section>

		<section class="pgi-step">
			<h2>Counters and doctor rooms</h2><p class="d">Registration counters are numbered from the ground floor up. You can rename rooms and add floors later in Admin → Settings.</p>
			<div class="pgi-grid">
				<label>Counters on the Ground Floor<input type="number" name="counters_ground" min="0" max="20" value="<?php echo (int) ($counts['Ground Floor'] ?? 3); ?>"></label>
				<label>Counters on the First Floor<input type="number" name="counters_first" min="0" max="20" value="<?php echo (int) ($counts['First Floor'] ?? 3); ?>"></label>
				<label>Number of doctor rooms<input type="number" name="rooms" min="1" max="60" value="<?php echo count($s['rooms']); ?>"></label>
				<label>Doctor rooms are on<input type="text" name="rooms_floor" value="<?php echo esc_attr($s['rooms'][0]['floor'] ?? 'First Floor'); ?>"></label>
			</div>
		</section>

		<section class="pgi-step">
			<h2>Departments and doctors</h2><p class="d">Neurology (Mon, Wed, Fri) and Neurosurgery (Tue, Thu, Sat) are created with their OPD days.</p>
			<label style="display:flex;gap:10px;align-items:flex-start;font-weight:600"><input type="checkbox" name="load_doctors" value="1" checked style="margin-top:3px">
				<span>Load the PGIMER OPD doctor list (26 doctors with their days)<br><span style="font-weight:400;color:#646970">Doctors that already exist are not added twice. Admin can change everything later.</span></span></label>
		</section>

		<section class="pgi-step">
			<h2>Staff logins</h2><p class="d">These accounts sign in on the token screens. Passwords need at least 8 characters. Leave a password empty to keep an existing account's password.</p>
			<table class="pgi-staff"><thead><tr><th>Who</th><th>Username</th><th>Password</th></tr></thead><tbody>
			<?php foreach ([['admin', 'Admin (all screens and settings)', 'Ankit'], ['counter', 'Registration counters', 'counter'], ['doctor', 'Doctors', 'doctor'], ['ha', 'Room attendants (phones)', 'attendant']] as [$k, $label, $def]) {
				$l = $login($k, $def); $exists = (bool) get_user_by('login', $l); ?>
				<tr><td><b><?php echo esc_html($label); ?></b></td><td><input type="text" name="user_<?php echo $k; ?>" value="<?php echo esc_attr($l); ?>"></td>
				<td><input type="password" name="pass_<?php echo $k; ?>" minlength="8" autocomplete="new-password" placeholder="<?php echo $exists ? 'Keep current password' : 'New password'; ?>" <?php echo $exists ? '' : 'required'; ?>></td></tr>
			<?php } ?>
			</tbody></table>
		</section>

		<div class="pgi-nav"><button type="button" class="button button-large" id="pgiBack">Back</button>
			<button type="button" class="button button-primary button-large" id="pgiNext">Next</button>
			<button type="submit" class="button button-primary button-large" id="pgiGo" hidden>Install</button></div>
	</form>
	<script>
	(() => {
		const steps = [...document.querySelectorAll('.pgi-step')], tabs = [...document.querySelectorAll('#pgiSteps span')];
		let i = 0;
		const show = n => {
			if (n > i) { const bad = [...steps[i].querySelectorAll('input,select')].find(x => !x.checkValidity()); if (bad) { bad.reportValidity(); return; } }
			i = Math.max(0, Math.min(steps.length - 1, n));
			steps.forEach((s, k) => s.classList.toggle('on', k === i));
			tabs.forEach((t, k) => t.className = k === i ? 'on' : k < i ? 'ok' : '');
			pgiBack.style.visibility = i ? 'visible' : 'hidden';
			pgiNext.hidden = i === steps.length - 1; pgiGo.hidden = !pgiNext.hidden;
		};
		pgiNext.onclick = () => show(i + 1); pgiBack.onclick = () => show(i - 1);
		pgiForm.onsubmit = () => { pgiGo.disabled = true; pgiGo.textContent = 'Installing…'; };
		show(0);
	})();
	</script>
	<?php } ?>
	</div></div>
	<?php
}
