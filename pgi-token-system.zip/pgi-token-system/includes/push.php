<?php
if (!defined('ABSPATH')) exit;

/*
 * Web push (works on Android Chrome, desktop browsers, and iPhone 16.4+ when the app is added to the Home Screen).
 * Standard VAPID + aes128gcm encryption (RFC 8291 / 8292) using PHP's OpenSSL, so no extra libraries are needed.
 */

function pgi_b64u($s) { return rtrim(strtr(base64_encode($s), '+/', '-_'), '='); }
function pgi_b64u_dec($s) { return base64_decode(strtr((string) $s, '-_', '+/') . str_repeat('=', (4 - strlen((string) $s) % 4) % 4)); }
function pgi_push_ready() { return function_exists('openssl_pkey_new') && function_exists('openssl_pkey_derive') && in_array('aes-128-gcm', openssl_get_cipher_methods(), true); }

function pgi_ec_new() {
	return openssl_pkey_new(['curve_name' => 'prime256v1', 'private_key_type' => OPENSSL_KEYTYPE_EC]);
}
function pgi_ec_point($key) { // 65-byte uncompressed public point
	$d = openssl_pkey_get_details($key);
	return "\x04" . str_pad($d['ec']['x'], 32, "\0", STR_PAD_LEFT) . str_pad($d['ec']['y'], 32, "\0", STR_PAD_LEFT);
}
function pgi_ec_public_pem($point) { // raw P-256 point -> PEM public key
	$der = hex2bin('3059301306072a8648ce3d020106082a8648ce3d030107034200') . $point;
	return "-----BEGIN PUBLIC KEY-----\n" . chunk_split(base64_encode($der), 64, "\n") . "-----END PUBLIC KEY-----\n";
}

// VAPID keys are made once (setup wizard or first use) and kept in the database
function pgi_vapid() {
	$v = get_option('pgi_vapid');
	if (is_array($v) && !empty($v['private']) && !empty($v['public'])) return $v;
	if (!pgi_push_ready()) return null;
	$k = pgi_ec_new(); if (!$k) return null;
	openssl_pkey_export($k, $pem);
	$v = ['private' => $pem, 'public' => pgi_b64u(pgi_ec_point($k))];
	update_option('pgi_vapid', $v, false);
	return $v;
}
function pgi_vapid_public() { $v = pgi_vapid(); return $v ? $v['public'] : ''; }

function pgi_der_to_raw($der) { // ECDSA DER signature -> 64-byte r||s (what JWT ES256 needs)
	$p = 2; if (ord($der[1]) & 0x80) $p += ord($der[1]) & 0x7f;
	$out = '';
	for ($i = 0; $i < 2; $i++) {
		$len = ord($der[$p + 1]); $n = substr($der, $p + 2, $len); $p += 2 + $len;
		$out .= str_pad(ltrim($n, "\0"), 32, "\0", STR_PAD_LEFT);
	}
	return $out;
}
function pgi_vapid_header($endpoint) {
	$v = pgi_vapid(); if (!$v) return null;
	$u = wp_parse_url($endpoint);
	$h = pgi_b64u(wp_json_encode(['typ' => 'JWT', 'alg' => 'ES256']));
	$c = pgi_b64u(wp_json_encode(['aud' => $u['scheme'] . '://' . $u['host'], 'exp' => time() + 12 * 3600, 'sub' => 'mailto:' . get_option('admin_email', 'admin@example.com')], JSON_UNESCAPED_SLASHES));
	if (!openssl_sign("$h.$c", $sig, $v['private'], OPENSSL_ALGO_SHA256)) return null;
	return 'vapid t=' . "$h.$c." . pgi_b64u(pgi_der_to_raw($sig)) . ', k=' . $v['public'];
}

// RFC 8291 message encryption for one subscription
function pgi_push_encrypt($payload, $p256dh, $authSecret) {
	$ua = pgi_b64u_dec($p256dh); $auth = pgi_b64u_dec($authSecret);
	if (strlen($ua) !== 65 || strlen($auth) < 16) return null;
	$as = pgi_ec_new(); $asPub = pgi_ec_point($as);
	$secret = openssl_pkey_derive(openssl_pkey_get_public(pgi_ec_public_pem($ua)), $as, 32);
	if (!$secret) return null;
	$ikm = hash_hmac('sha256', "WebPush: info\0" . $ua . $asPub . "\x01", hash_hmac('sha256', $secret, $auth, true), true);
	$salt = random_bytes(16);
	$prk = hash_hmac('sha256', $ikm, $salt, true);
	$cek = substr(hash_hmac('sha256', "Content-Encoding: aes128gcm\0\x01", $prk, true), 0, 16);
	$nonce = substr(hash_hmac('sha256', "Content-Encoding: nonce\0\x01", $prk, true), 0, 12);
	$ct = openssl_encrypt($payload . "\x02", 'aes-128-gcm', $cek, OPENSSL_RAW_DATA, $nonce, $tag);
	if ($ct === false) return null;
	return $salt . pack('N', 4096) . chr(65) . $asPub . $ct . $tag;
}

// Only real push services are contacted (stops the server being used to call other addresses)
function pgi_push_host_ok($endpoint) {
	$u = wp_parse_url($endpoint);
	if (!$u || ($u['scheme'] ?? '') !== 'https' || empty($u['host'])) return false;
	$hosts = apply_filters('pgi_push_hosts', ['fcm.googleapis.com', 'android.googleapis.com', 'updates.push.services.mozilla.com', 'push.services.mozilla.com', 'web.push.apple.com', 'notify.windows.com']);
	foreach ($hosts as $h) if ($u['host'] === $h || substr($u['host'], -strlen($h) - 1) === '.' . $h) return true;
	return false;
}

// Sends one notification. Returns true when the push service accepted it.
function pgi_push_send($sub, $msg, $urgency = 'high') {
	if (!pgi_push_ready()) return false;
	$auth = pgi_vapid_header($sub['endpoint']);
	$body = pgi_push_encrypt(wp_json_encode($msg, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $sub['p256dh'], $sub['auth']);
	if (!$auth || $body === null) return false;
	$r = wp_remote_post($sub['endpoint'], ['timeout' => 5, 'body' => $body, 'headers' => [
		'Authorization' => $auth, 'TTL' => '3600', 'Urgency' => $urgency, 'Content-Encoding' => 'aes128gcm', 'Content-Type' => 'application/octet-stream',
	]]);
	if (is_wp_error($r)) return false;
	$code = (int) wp_remote_retrieve_response_code($r);
	if ($code === 404 || $code === 410) { global $wpdb; $wpdb->delete(pgi_t('push_subs'), ['id' => (int) $sub['id']]); } // phone unsubscribed
	return $code >= 200 && $code < 300;
}
function pgi_push_many($rows, $msg, $urgency = 'high') { $n = 0; foreach ($rows as $s) if (pgi_push_send($s, $msg, $urgency)) $n++; return $n; }
function pgi_app_url($page) { return wp_make_link_relative(home_url('/' . PGI_SLUG . '/' . $page)); }

// ---------- REST: subscribe / unsubscribe / test ----------
function pgi_push_subscribe($b) {
	global $wpdb;
	$sub = $b['sub'] ?? []; $ep = (string) ($sub['endpoint'] ?? ''); $keys = $sub['keys'] ?? [];
	if (!pgi_push_host_ok($ep) || empty($keys['p256dh']) || empty($keys['auth'])) return pgi_err('This browser gave an invalid subscription');
	$kind = (string) ($b['kind'] ?? ''); $row = ['kind' => $kind, 'room' => null, 'doctor' => null, 'token_id' => null, 'user_id' => get_current_user_id()];
	if ($kind === 'patient') {
		$t = pgi_find_token($b['id'] ?? 0);
		if (!$t || !hash_equals($t['secret'], (string) ($b['k'] ?? ''))) return pgi_err('Token not found', 404);
		$row['token_id'] = (int) $t['id'];
	} elseif ($kind === 'doctor' || $kind === 'ha') {
		$r = pgi_role();
		if (!$r || ($r !== 'admin' && $r !== $kind && !($kind === 'ha' && $r === 'doctor'))) return pgi_err('Sign in required', 401);
		$rm = pgi_room_of(pgi_settings(), $b['room'] ?? 0); if (!$rm) return pgi_err('Choose your room');
		$row['room'] = (int) $rm['id']; $row['doctor'] = !empty($b['doctor']) ? (int) $b['doctor'] : null;
	} else return pgi_err('Unknown alert type');
	$row += ['endpoint' => $ep, 'hash' => sha1($ep), 'p256dh' => substr((string) $keys['p256dh'], 0, 120), 'auth' => substr((string) $keys['auth'], 0, 40), 'created' => pgi_now()];
	$T = pgi_t('push_subs');
	$id = $wpdb->get_var($wpdb->prepare("SELECT id FROM $T WHERE hash=%s", $row['hash']));
	if ($id) $wpdb->update($T, $row, ['id' => $id]); else $wpdb->insert($T, $row);
	return pgi_ok();
}
function pgi_push_unsubscribe($b) {
	global $wpdb;
	$wpdb->delete(pgi_t('push_subs'), ['hash' => sha1((string) ($b['endpoint'] ?? ''))]);
	return pgi_ok();
}
function pgi_push_test($b) {
	global $wpdb;
	$s = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . pgi_t('push_subs') . " WHERE hash=%s", sha1((string) ($b['endpoint'] ?? ''))), ARRAY_A);
	if (!$s) return pgi_err('Alerts are not on for this phone', 404);
	$ok = pgi_push_send($s, ['title' => 'Alerts are working', 'body' => 'सूचनाएं चालू हैं · ' . pgi_settings()['hospital'], 'tag' => 'test', 'url' => '']);
	return $ok ? pgi_ok() : pgi_err('The push service did not accept the alert. Check that the site uses HTTPS and the server can reach the internet.', 502);
}
// Patient subscriptions end with the day
function pgi_push_cleanup() {
	global $wpdb;
	$wpdb->query($wpdb->prepare("DELETE FROM " . pgi_t('push_subs') . " WHERE kind='patient' AND token_id IN (SELECT id FROM " . pgi_t('tokens') . " WHERE day<%s)", pgi_today()));
}

// ---------- when to notify ----------
// Patient: their token was called to a counter or a doctor room
function pgi_push_call($t, $c) {
	global $wpdb;
	$rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM " . pgi_t('push_subs') . " WHERE kind='patient' AND token_id=%d", $t['id']), ARRAY_A);
	if (!$rows) return;
	$where = ($c['kind'] === 'room' ? 'Room ' : 'Counter ') . $c['place'] . ($c['floor'] ? ', ' . $c['floor'] : '');
	$hi = ($c['kind'] === 'room' ? 'कमरा ' : 'काउंटर ') . $c['place'];
	pgi_push_many($rows, ['title' => "Token {$t['token']}: please go to $where", 'body' => "टोकन {$t['token']}: कृपया $hi पर जाएं", 'tag' => 'call-' . $t['id'],
		'url' => pgi_status_url($t), 'kind' => 'patient']);
}
// Doctor / attendant: a new patient was sent to their room
function pgi_push_new_patient($token, $room, $doctor) {
	global $wpdb;
	if (!$room || pgi_settings()['doctorBeep'] === false) return;
	$rm = pgi_room_of(pgi_settings(), $room);
	$rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM " . pgi_t('push_subs') . " WHERE kind IN ('doctor','ha') AND room=%d", $room), ARRAY_A);
	foreach ($rows as $r) pgi_push_send($r, ['title' => "New patient $token", 'body' => 'Room ' . ($rm['no'] ?? $room) . ' · नया मरीज़', 'tag' => 'new-' . $room, 'kind' => 'new',
		'url' => $r['kind'] === 'doctor' ? pgi_app_url('doctor.html?room=' . (int) $room . ($r['doctor'] ? '&doctor=' . (int) $r['doctor'] : '')) : pgi_app_url('ha.html?room=' . (int) $room)], 'normal');
}
// Attendant: the doctor pressed "Call attendant"
function pgi_push_ha_call($rm) {
	global $wpdb;
	$rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM " . pgi_t('push_subs') . " WHERE kind='ha' AND room=%d", $rm['id']), ARRAY_A);
	pgi_push_many($rows, ['title' => 'Doctor is calling you · Room ' . $rm['no'], 'body' => 'डॉक्टर आपको बुला रहे हैं · कमरा ' . $rm['no'], 'tag' => 'ha-' . $rm['id'], 'kind' => 'ring',
		'url' => pgi_app_url('ha.html?room=' . (int) $rm['id'])]);
}
