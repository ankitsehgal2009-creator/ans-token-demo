<?php
if (!defined('ABSPATH')) exit;

// ---------- settings ----------
const PGI_HOSPITAL = 'Post Graduate Institute of Medical Education & Research, Chandigarh';

function pgi_defaults() {
	return [
		'hospital' => PGI_HOSPITAL, 'building' => '', 'tagline' => '', 'theme' => 'teal', 'character' => 'nurse',
		'counters' => array_map(function ($n) { return ['no' => $n, 'floor' => $n <= 3 ? 'Ground Floor' : 'First Floor']; }, [1, 2, 3, 4, 5, 6]),
		'rooms' => array_map(function ($n) { return ['id' => $n, 'no' => (string) $n, 'floor' => 'First Floor']; }, [1, 2, 3, 4]),
		'floorAssign' => 'balance', 'rate' => 0.9, 'langs' => ['en', 'hi'], 'toneCounter' => 'soft', 'toneRoom' => 'bell',
		'avgServiceMinutes' => 5, 'kioskDetails' => true, 'kioskEmergency' => true, 'logo' => '',
		'voice' => ['en' => ['name' => '', 'rate' => 0.95, 'pitch' => 1.05], 'hi' => ['name' => '', 'rate' => 0.95, 'pitch' => 1.15]],
		'volume' => 1, 'repeat' => 1, 'styleEn' => 'standard', 'styleHi' => 'standard',
		'patientNotes' => "OPD registration: Monday to Friday 8:00 am to 11:00 am\nSaturday and gazetted holidays: 8:00 am to 10:30 am\nओपीडी पंजीकरण: सोमवार से शुक्रवार सुबह 8:00 से 11:00 बजे तक, शनिवार और राजपत्रित अवकाश: सुबह 8:00 से 10:30 बजे तक",
		'scheduleUrl' => 'https://pgimer.edu.in/PGIMER_PORTAL/PGIMERPORTAL/Department/PatientCare/JSP/OPD_Schedule.jsp',
		'displays' => new stdClass(), 'doctorBeep' => true,
	];
}
function pgi_settings() {
	$s = get_option('pgi_settings', []);
	return array_merge(pgi_defaults(), is_array($s) ? $s : []);
}
function pgi_save_settings($s) { update_option('pgi_settings', $s, true); }

// ---------- time & small helpers ----------
function pgi_now() { return gmdate('Y-m-d\TH:i:s\Z'); }       // ISO time, as the screens expect
function pgi_today() { return wp_date('Y-m-d'); }             // hospital's date (WordPress timezone setting)
function pgi_weekday() { return (int) wp_date('w'); }         // 0 = Sunday
function pgi_on_day($days, $wd = null) {
	if ($days === '' || $days === null) return true;
	return in_array($wd ?? pgi_weekday(), array_map('intval', explode(',', $days)), true);
}
function pgi_clean($v, $max = 60) { return mb_substr(trim(str_replace(['<', '>'], '', (string) $v)), 0, $max); }
function pgi_days_param($v) {
	$a = is_array($v) ? $v : explode(',', (string) $v);
	$a = array_values(array_unique(array_filter(array_map('intval', array_filter($a, 'is_numeric')), function ($n) { return $n >= 0 && $n <= 6; })));
	sort($a);
	return implode(',', $a);
}
function pgi_clamp($v, $a, $b, $d) { return is_numeric($v) ? max($a, min($b, +$v)) : $d; }
function pgi_room_of($s, $id) { foreach ($s['rooms'] as $r) if ((int) $r['id'] === (int) $id) return $r; return null; }
function pgi_counter_of($s, $no) { foreach ($s['counters'] as $c) if ((int) $c['no'] === (int) $no) return $c; return null; }
function pgi_floors($s) { return array_values(array_unique(array_map(function ($c) { return $c['floor'] ?? ''; }, $s['counters']))); }
const PGI_PRIORITY = [0 => 'Normal', 1 => 'Senior Citizen / Disabled', 2 => 'Emergency'];

// Rows come back from MySQL as strings; give the screens real numbers
function pgi_int_fields($row, $fields) {
	if (!$row) return $row;
	foreach ($fields as $f) if (array_key_exists($f, $row) && $row[$f] !== null) $row[$f] = (int) $row[$f];
	return $row;
}
const PGI_TOKEN_INTS = ['id', 'num', 'dept', 'priority', 'counter', 'room', 'doctor'];

// ---------- live version, call, attendant calls ----------
// Every change bumps the version; screens poll and only download the state when it changed.
function pgi_bump() { update_option('pgi_version', (int) get_option('pgi_version', 0) + 1, true); }
function pgi_version() { return (int) get_option('pgi_version', 0); }
function pgi_call() { return get_option('pgi_call', null) ?: null; }
function pgi_set_call($t, $kind, $place, $floor) {
	$c = ['id' => (int) round(microtime(true) * 1000), 'token' => $t['token'], 'dept' => (int) $t['dept'], 'kind' => $kind, 'place' => $place, 'floor' => $floor ?: null, 'priority' => (int) $t['priority']];
	update_option('pgi_call', $c, true);
	pgi_push_call($t, $c); // patient's phone (if they turned on notifications on their status page)
	return $c;
}
function pgi_ha_calls() { $h = get_option('pgi_ha_calls', []); return is_array($h) ? $h : []; }

// Day change: clear the announcement and mark tokens left open from earlier days as missed
function pgi_day_check() {
	$today = pgi_today();
	if (get_option('pgi_last_day') === $today) return;
	update_option('pgi_last_day', $today, true);
	update_option('pgi_call', null, true);
	update_option('pgi_ha_calls', [], true);
	pgi_close_old_days();
	pgi_push_cleanup();
	pgi_bump();
}
function pgi_close_old_days() {
	global $wpdb;
	$n = $wpdb->query($wpdb->prepare("UPDATE " . pgi_t('tokens') . " SET status='missed', updated=%s WHERE day<%s AND status IN ('waiting','called','consult','room')", pgi_now(), pgi_today()));
	if ($n) pgi_log('day-close', null, null, "$n pending tokens marked missed");
}

function pgi_log($action, $token = null, $place = null, $details = '', $user = null) {
	global $wpdb;
	if ($user === null) { $u = wp_get_current_user(); $user = $u && $u->ID ? $u->user_login : 'kiosk'; }
	$wpdb->insert(pgi_t('audit'), ['ts' => pgi_now(), 'user' => $user, 'action' => $action, 'token' => $token, 'place' => $place === null ? null : (string) $place, 'details' => mb_substr((string) $details, 0, 255)]);
}

// ---------- departments, doctors ----------
function pgi_depts() {
	global $wpdb;
	return array_map(function ($d) {
		$d = pgi_int_fields($d, ['id', 'active', 'sort']);
		$d['openToday'] = $d['active'] && pgi_on_day($d['days']);
		return $d;
	}, $wpdb->get_results("SELECT * FROM " . pgi_t('departments') . " ORDER BY sort, id", ARRAY_A) ?: []);
}
function pgi_doctor_types() {
	global $wpdb;
	return array_map(function ($t) { return pgi_int_fields($t, ['id', 'active', 'sort']); }, $wpdb->get_results("SELECT * FROM " . pgi_t('doctor_types') . " ORDER BY sort, id", ARRAY_A) ?: []);
}
// today: sits today (active, their days, type enabled, or signed in at the doctor desk). todayRoom: room picked at the desk today, else usual room
function pgi_doctors() {
	global $wpdb;
	$types = []; foreach (pgi_doctor_types() as $t) $types[$t['id']] = $t;
	$ci = []; foreach ($wpdb->get_results($wpdb->prepare("SELECT doctor, room FROM " . pgi_t('checkins') . " WHERE day=%s", pgi_today()), ARRAY_A) ?: [] as $c) $ci[(int) $c['doctor']] = (int) $c['room'];
	return array_map(function ($d) use ($types, $ci) {
		$d = pgi_int_fields($d, ['id', 'dept', 'room', 'active', 'type']);
		$t = $d['type'] ? ($types[$d['type']] ?? null) : null; $in = isset($ci[$d['id']]);
		$d['typeName'] = $t ? $t['name'] : '';
		$d['today'] = $d['active'] && (!$t || $t['active']) && ($in || pgi_on_day($d['days']));
		$d['todayRoom'] = $in ? $ci[$d['id']] : $d['room'];
		$d['checkedIn'] = $in;
		return $d;
	}, $wpdb->get_results("SELECT * FROM " . pgi_t('doctors') . " ORDER BY name", ARRAY_A) ?: []);
}

// ---------- tokens ----------
function pgi_token_rows($staff) {
	global $wpdb;
	$cols = 'id,token,num,dept,priority,status,counter,room,doctor,floor,created,called_at,registered_at,room_at,done_at,updated' . ($staff ? ',name,phone,age,gender,note,source' : '');
	return array_map(function ($t) { return pgi_int_fields($t, PGI_TOKEN_INTS); },
		$wpdb->get_results($wpdb->prepare("SELECT $cols FROM " . pgi_t('tokens') . " WHERE day=%s ORDER BY id", pgi_today()), ARRAY_A) ?: []);
}
function pgi_find_token($id) {
	global $wpdb;
	return pgi_int_fields($wpdb->get_row($wpdb->prepare("SELECT * FROM " . pgi_t('tokens') . " WHERE id=%d AND day=%s", (int) $id, pgi_today()), ARRAY_A), PGI_TOKEN_INTS);
}
function pgi_update_token($id, $fields) { global $wpdb; $fields['updated'] = pgi_now(); $wpdb->update(pgi_t('tokens'), $fields, ['id' => (int) $id]); }

function pgi_state($staff) {
	$docs = array_map(function ($d) {
		return array_intersect_key($d, array_flip(['id', 'name', 'dept', 'room', 'days', 'active', 'today', 'type', 'typeName', 'todayRoom', 'checkedIn']));
	}, pgi_doctors());
	return ['settings' => pgi_settings(), 'departments' => pgi_depts(), 'doctors' => $docs, 'doctorTypes' => pgi_doctor_types(),
		'tokens' => pgi_token_rows($staff), 'call' => pgi_call(), 'version' => pgi_version(), 'app' => PGI_VERSION, 'serverTime' => pgi_now(),
		'weekday' => pgi_weekday(), 'staff' => (bool) $staff, 'haCalls' => $staff ? (object) pgi_ha_calls() : new stdClass()];
}

function pgi_ahead($t) {
	global $wpdb;
	return (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM " . pgi_t('tokens') . " WHERE day=%s AND status='waiting'
		AND (" . ($t['floor'] === null ? '1=1' : $wpdb->prepare('(floor=%s OR floor IS NULL)', $t['floor'])) . ")
		AND (priority>%d OR (priority=%d AND id<%d))", $t['day'], $t['priority'], $t['priority'], $t['id']));
}
// Floor with the shortest queue per counter, so both floors stay equally busy
function pgi_pick_floor($s) {
	global $wpdb;
	$floors = pgi_floors($s);
	if (($s['floorAssign'] ?? '') !== 'balance' || count($floors) < 2) return null;
	$best = null; $bestLoad = INF;
	foreach ($floors as $f) {
		$n = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM " . pgi_t('tokens') . " WHERE day=%s AND status='waiting' AND floor=%s", pgi_today(), $f));
		$load = $n / max(1, count(array_filter($s['counters'], function ($c) use ($f) { return ($c['floor'] ?? '') === $f; })));
		if ($load < $bestLoad) { $best = $f; $bestLoad = $load; }
	}
	return $best;
}
function pgi_wait_for($s, $n) { return $s['avgServiceMinutes'] > 0 ? $n * $s['avgServiceMinutes'] : null; }

function pgi_status_url($t) { return wp_make_link_relative(home_url('/' . PGI_SLUG . '/status.html')) . '?id=' . $t['id'] . '&k=' . $t['secret']; }
function pgi_slip_info($t, $s) {
	global $wpdb;
	$d = pgi_int_fields($wpdb->get_row($wpdb->prepare("SELECT * FROM " . pgi_t('departments') . " WHERE id=%d", $t['dept']), ARRAY_A), ['id', 'active', 'sort']);
	$doc = $t['doctor'] ? $wpdb->get_var($wpdb->prepare("SELECT name FROM " . pgi_t('doctors') . " WHERE id=%d", $t['doctor'])) : null;
	$room = $t['room'] ? pgi_room_of($s, $t['room']) : null;
	$a = $t['status'] === 'waiting' ? pgi_ahead($t) : 0;
	return ['id' => $t['id'], 'token' => $t['token'], 'dept' => $d, 'priority' => $t['priority'], 'status' => $t['status'], 'issuedAt' => $t['created'], 'floor' => $t['floor'],
		'counters' => $t['floor'] ? array_values(array_map(function ($c) { return $c['no']; }, array_filter($s['counters'], function ($c) use ($t) { return ($c['floor'] ?? '') === $t['floor']; }))) : [],
		'doctor' => $doc, 'room' => $room ? $room['no'] : null, 'roomFloor' => $room['floor'] ?? null,
		'ahead' => $a, 'waitMinutes' => pgi_wait_for($s, $a), 'statusUrl' => pgi_status_url($t)];
}

// One-time load of the PGIMER OPD schedule (pgimer.edu.in, Oct 2026). Admin can change everything later.
function pgi_pgi_schedule() {
	return [
		'N' => ['Neurology', 'न्यूरोलॉजी', '#0f766e', '2nd Level, Neurology Block, ANS', '1,3,5', [['Aastha Takkar Kapila', '1,3,5'], ['Dheeraj Khurana', '3,5'], ['Manish Modi', '3,5'], ['Manoj Kumar Goyal', '3,5'],
			['Parampreet Singh Kharbanda', '1,5'], ['Rajveer Singh', '1,3,5'], ['Sahil Mehta', '1,3'], ['Sucharita Ray', '1,3,5'], ['Vivek Lal', '1,3,5']]],
		'S' => ['Neurosurgery', 'न्यूरोसर्जरी', '#2563eb', '2nd Level, Neurosurgery Block, ANS', '2,4,6', [['Ashish Aggarwal', '2'], ['Chandra Shekhar Gendle', '2'], ['Dhandapani Sivashanmugam', '2,6'],
			['Manju Mohanty', '2,4,6'], ['Navneet Singla', '2,4'], ['Pravin Salunke', '2,4'], ['Saravanan Sadhasivam', '2'], ['Sunil Kumar Gupta', '2'], ['Sushanta Kumar Sahoo', '2'],
			['Aman Batish', '4'], ['Karthigeyan M', '4'], ['Manjul Tripathi', '4'], ['Rajesh Chhabra', '4'], ['Sandeep Mohindra', '4,6'],
			['Apinderpreet Singh', '6'], ['Harsimrat Bir Singh Sodhi', '6'], ['Hitesh Inder Singh Rai', '6']]],
	];
}
function pgi_seed($withDoctors) {
	global $wpdb;
	if (!(int) $wpdb->get_var("SELECT COUNT(*) FROM " . pgi_t('doctor_types')))
		foreach (['Faculty / Consultant', 'Senior Resident', 'Junior Resident'] as $i => $n) $wpdb->insert(pgi_t('doctor_types'), ['name' => $n, 'sort' => $i]);
	$faculty = (int) $wpdb->get_var("SELECT id FROM " . pgi_t('doctor_types') . " ORDER BY sort, id LIMIT 1");
	$i = 0;
	foreach (pgi_pgi_schedule() as $code => [$name, $local, $color, $loc, $days, $docs]) {
		$id = $wpdb->get_var($wpdb->prepare("SELECT id FROM " . pgi_t('departments') . " WHERE code=%s", $code));
		if (!$id) { $wpdb->insert(pgi_t('departments'), ['code' => $code, 'name' => $name, 'name_local' => $local, 'color' => $color, 'sort' => $i, 'days' => $days, 'location' => $loc]); $id = $wpdb->insert_id; }
		$i++;
		if ($withDoctors) foreach ($docs as [$dn, $dd])
			if (!$wpdb->get_var($wpdb->prepare("SELECT id FROM " . pgi_t('doctors') . " WHERE name=%s", $dn)))
				$wpdb->insert(pgi_t('doctors'), ['name' => $dn, 'dept' => $id, 'room' => null, 'days' => $dd, 'active' => 1, 'type' => $faculty]);
	}
}
