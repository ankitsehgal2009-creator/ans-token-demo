// ANS Token System v2 — shared browser helpers
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

// WordPress passes the REST address, the sign-in nonce, the app's base path and the push key (see includes/app.php)
const PGI = Object.assign({ api: '/wp-json/pgi-token/v1/', nonce: '', base: '/token/', vapid: '' }, window.PGI || {});
function apiUrl(path, withNonce) {
  const [p, q] = String(path).split('?'), u = PGI.api + p; // PGI.api may already hold "?rest_route=" on sites without pretty links
  const params = [q, withNonce && PGI.nonce ? '_wpnonce=' + PGI.nonce : ''].filter(Boolean).join('&');
  return params ? u + (u.includes('?') ? '&' : '?') + params : u;
}
async function api(path, body) {
  const h = { 'Content-Type': 'application/json' }; if (PGI.nonce) h['X-WP-Nonce'] = PGI.nonce;
  const r = await fetch(apiUrl(path), { method: body ? 'POST' : 'GET', headers: h, credentials: 'same-origin', cache: 'no-store', body: body ? JSON.stringify(body) : undefined });
  const data = await r.json().catch(() => ({}));
  if (data.code === 'rest_cookie_invalid_nonce') { location.reload(); return { error: 'Session expired, reloading…' }; } // nonce is older than a day
  if (!r.ok && !data.error) data.error = data.message || 'Request failed (' + r.status + ')';
  return data;
}
// QR codes are drawn in the browser (qrcode.js), so no image service is needed
function qrSVG(text) {
  try { const q = qrcode(0, 'M'); q.addData(String(text || ' ')); q.make(); return q.createSvgTag({ cellSize: 4, margin: 2, scalable: true }); } catch { return ''; }
}
// Runs an action and shows a toast for errors (or success text when given)
async function act(path, body, okText) {
  const r = await api(path, body);
  if (r.error) toast(r.error, true); else if (okText) toast(okText);
  return r;
}
function toast(msg, err) {
  let box = $('#toasts');
  if (!box) { box = document.createElement('div'); box.id = 'toasts'; document.body.append(box); }
  const t = document.createElement('div'); t.className = 'toast' + (err ? ' err' : ''); t.textContent = msg; box.append(t);
  setTimeout(() => t.remove(), 3500);
}

// Live state: every screen asks the server every 2 seconds; the server answers "same" unless something changed.
// cb(state, freshCall): freshCall is true when a new announcement was made since the last update.
function live(cb) {
  let last = null, ver = -1, S = null;
  const status = ok => $$('.live').forEach(e => { e.classList.toggle('off', !ok); e.textContent = ok ? 'Live' : 'Reconnecting…'; });
  const poll = async () => {
    try {
      const s = await api('state?v=' + ver);
      if (s.error) throw 0;
      status(true);
      if (s.app && PGI.app && s.app !== PGI.app) { location.reload(); return; } // plugin was updated: load the new screens
      if (!s.same) {
        S = s; ver = s.version;
        const id = s.call ? s.call.id : 0;
        applyTheme(s.settings.theme); applyLogo(s.settings);
        cb(s, last !== null && id !== last && !!s.call); fxScan();
        last = id;
      }
    } catch { status(false); }
    setTimeout(poll, document.hidden ? 5000 : 2000);
  };
  poll();
  live.refresh = () => { ver = -1; };
}
function liveReconnect() { }
// Hospital logo (uploaded in Admin → Settings) replaces the plus icon everywhere
function applyLogo(st) {
  $$('.logo').forEach(el => {
    if (st.logo) { if (el.dataset.src !== st.logo) { el.dataset.src = st.logo; el.innerHTML = `<img src="${esc(st.logo)}" alt="">`; el.classList.add('img'); } }
    else if (el.dataset.src) { delete el.dataset.src; el.innerHTML = ICON.logo; el.classList.remove('img'); }
  });
}
function applyTheme(t) { if (!document.body.dataset.fixedTheme) document.documentElement.dataset.theme = t || 'teal'; }

// ---------- auth ----------
async function auth(roles, { onLogin } = {}) {
  const me = await api('me');
  if (me.role && (roles.includes(me.role) || me.role === 'admin')) return me;
  const state = await api('state');
  applyTheme(state.settings?.theme);
  document.body.innerHTML = `<div class="login"><form id="lf" class="card stack" autocomplete="on">
    <div class="row"><div class="logo">${ICON.logo}</div><div><h2>Staff sign in</h2><div class="muted small">${esc(state.settings?.hospital || '')}</div></div></div>
    <label class="field">Username<input class="input" id="u" autocomplete="username" required autofocus></label>
    <label class="field">Password<input class="input" id="p" type="password" autocomplete="current-password" required></label>
    <button class="btn primary lg">Sign in</button><div id="err" class="small" style="color:var(--danger);min-height:1.2em"></div>
    ${navButtons()}</form></div>`;
  applyLogo(state.settings || {});
  return new Promise(() => {
    $('#lf').onsubmit = async e => {
      e.preventDefault();
      const r = await api('login', { user: $('#u').value, pass: $('#p').value });
      if (r.role && (roles.includes(r.role) || r.role === 'admin')) { onLogin?.(); liveReconnect(); setTimeout(() => location.reload(), 150); }
      else $('#err').textContent = r.error || 'This account cannot open this page';
    };
  });
}
// Back + Home buttons, shown on every page
function navButtons(cls = '') {
  return `<div class="nav ${cls}"><button class="btn ghost sm" title="Back" onclick="history.length > 1 ? history.back() : (location.href=PGI.base)">${ICON.back}<span>Back</span></button>
    <a class="btn ghost sm" href="${PGI.base}" title="Home">${ICON.home}<span>Home</span></a></div>`;
}
function appbar(title, me, extra = '', nav = true) {
  return `<header class="appbar">${nav ? navButtons() : ''}<div class="logo">${ICON.logo}</div>
    <div class="title"><b>${esc(title)}</b><small id="hosp"></small></div><div class="spacer"></div>${extra}
    <span class="live">Live</span>
    ${me ? `<div class="who"><span class="avatar">${esc(me.user?.[0] || '?')}</span><span>${esc(me.user)}</span>
    <button class="btn ghost sm" onclick="api('logout',{}).then(()=>{ liveReconnect(); setTimeout(() => location.reload(), 150); })">Sign out</button></div>` : ''}</header>`;
}
const hospitalLine = st => [st.hospital, st.building].filter(Boolean).join(' · ');

// ---------- domain helpers ----------
const PRI = { 0: 'Normal', 1: 'Senior Citizen / Disabled', 2: 'Emergency' };
const PRI_HI = { 0: 'सामान्य', 1: 'वरिष्ठ / दिव्यांग', 2: 'आपातकालीन' };
const STATUS = { waiting: 'Waiting', called: 'At counter', consult: 'Waiting for doctor', room: 'With doctor', done: 'Completed', skipped: 'No show', cancelled: 'Cancelled', missed: 'Missed (day closed)' };
const priBadge = p => p == 2 ? '<span class="badge p2">Emergency</span>' : p == 1 ? '<span class="badge p1">Senior Citizen</span>' : '';
const statusBadge = s => `<span class="badge st-${s}">${STATUS[s] || s}</span>`;
const deptOf = (S, id) => S.departments.find(d => d.id === id) || { code: '?', name: 'Unknown', color: '#888' };
const fmtTime = iso => iso ? new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '—';
const minsSince = iso => iso ? Math.max(0, Math.round((Date.now() - new Date(iso)) / 60000)) : 0;
const byQueue = (a, b) => b.priority - a.priority || a.id - b.id;
const byDoctorQueue = (a, b) => b.priority - a.priority || (a.registered_at < b.registered_at ? -1 : 1);
const roomOf = (S, id) => S.settings.rooms.find(r => r.id === +id);
const roomName = (S, id) => { const r = roomOf(S, id); return r ? 'Room ' + r.no : '—'; };
const counterOf = (S, no) => S.settings.counters.find(c => c.no === +no);
const counterName = (S, no) => { const c = counterOf(S, no); return 'Counter ' + no + (c?.floor ? ' · ' + c.floor : ''); };
const floorsOf = S => [...new Set(S.settings.counters.map(c => c.floor || ''))].filter(Boolean);
const doctorOf = (S, id) => S.doctors.find(d => d.id === +id);
const doctorsInRoom = (S, roomId) => S.doctors.filter(d => d.today && (d.todayRoom ?? d.room) === +roomId).sort((a, b) => b.checkedIn - a.checkedIn);
const docName = d => d ? 'Dr. ' + d.name : '';
const docLabel = d => d ? docName(d) + (d.typeName ? ' · ' + d.typeName : '') : '';
// Sound settings for one screen (Admin → Settings → Displays & sound). key: 'hall:<floor>' | 'hall:all' | 'room:<id>' | 'counter' | 'doctor'
function displayCfg(st, key) {
  const d = st.displays?.[key] || {};
  return { ...st, audio: d.audio !== false, langs: d.langs?.length ? d.langs : st.langs, repeat: d.repeat || st.repeat || 1 };
}
// Patient notes (registration timings etc.) and the hospital's online OPD schedule
const notesLines = st => String(st.patientNotes || '').split('\n').filter(Boolean);
function notesHTML(st, { qr = '' } = {}) {
  const lines = notesLines(st);
  if (!lines.length && !st.scheduleUrl) return '';
  return `<div class="notes">${ICON.clock}<div class="stack" style="gap:4px">${lines.map(l => `<div>${esc(l)}</div>`).join('')}
    ${st.scheduleUrl ? `<div><a class="btn sm primary" href="${esc(st.scheduleUrl)}" target="_blank" rel="noopener">View full OPD schedule · ओपीडी समय-सारणी</a></div>` : ''}</div>${qr ? `<div class="nqr">${qr}<small>Scan for schedule</small></div>` : ''}</div>`;
}
const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const daysText = days => !days ? 'Every day' : String(days).split(',').map(d => DAYS[+d]).join(', ');
const opts = (n, sel, label = '') => Array.from({ length: n }, (_, i) => `<option value="${i + 1}" ${+sel === i + 1 ? 'selected' : ''}>${label}${i + 1}</option>`).join('');

const ICON = {
  back: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5M11 18l-6-6 6-6"/></svg>',
  home: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/></svg>',
  sound: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 5 6 9H2v6h4l5 4zM15.5 8.5a5 5 0 0 1 0 7M19 5a10 10 0 0 1 0 14"/></svg>',
  mute: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 5 6 9H2v6h4l5 4zM22 9l-6 6M16 9l6 6"/></svg>',
  print: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9V2h12v7M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>',
  logo: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>',
  next: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>',
  bell: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg>',
  check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>',
  x: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg>',
  users: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
  clock: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>',
  alert: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"/><path d="M12 9v4M12 17h.01"/></svg>',
  done: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><path d="M22 4 12 14.01l-3-3"/></svg>',
  steth: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4.8 2.3A.3.3 0 1 0 5 2H4a2 2 0 0 0-2 2v5a6 6 0 0 0 6 6 6 6 0 0 0 6-6V4a2 2 0 0 0-2-2h-1a.2.2 0 1 0 .3.3"/><path d="M8 15v1a6 6 0 0 0 6 6 6 6 0 0 0 6-6v-4"/><circle cx="20" cy="10" r="2"/></svg>',
  screen: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/></svg>',
  ticket: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 9a3 3 0 0 1 0 6v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a3 3 0 0 1 0-6V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z"/><path d="M13 5v2M13 17v2M13 11v2"/></svg>',
  desk: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 7h18v4H3zM5 11v9M19 11v9M9 7V4h6v3"/></svg>',
  gear: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/></svg>',
  door: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M13 4h3a2 2 0 0 1 2 2v14M2 20h3M13 20h9M10 12v.01M13 4.56v16.88a.5.5 0 0 1-.6.49L5 20V5.56a1 1 0 0 1 .76-.97l6-1.5A1 1 0 0 1 13 4.56Z"/></svg>',
};

// ---------- character ----------
function charSVG(t) { return `<svg class="char ${t || ''}" viewBox="0 0 220 260"><g class="body"><path d="M40 260C40 190 70 168 100 168S160 190 160 260Z" fill="var(--scrub)"/><path d="M88 168l12 22 12-22z" fill="#fff"/><path class="steth" d="M80 168C78 206 122 206 120 168" fill="none" stroke="#333" stroke-width="3"/><rect x="86" y="140" width="28" height="30" rx="10" fill="var(--skin)"/><path class="hb" d="M52 78C52 40 148 40 148 78V92H52Z" fill="var(--hair)"/><ellipse cx="100" cy="90" rx="42" ry="46" fill="var(--skin)"/><path d="M58 82C62 50 138 50 142 82 120 66 80 66 58 82Z" fill="var(--hair)"/><g class="cap"><rect x="78" y="40" width="44" height="16" rx="4" fill="#fff"/><path d="M97 43h6v10h-6zM94 46h12v4H94z" fill="#e5484d"/></g><g class="eyes"><circle cx="84" cy="86" r="4" fill="#222"/><circle cx="116" cy="86" r="4" fill="#222"/></g><circle cx="74" cy="100" r="6" fill="#f2a28f" opacity=".5"/><circle cx="126" cy="100" r="6" fill="#f2a28f" opacity=".5"/><path class="mouth" d="M85 100Q100 122 115 100Q100 107 85 100Z" fill="#a8323e" stroke="#a8323e" stroke-width="1.5" stroke-linejoin="round"/><path class="larm" d="M60 175C40 200 38 230 44 260H66C66 220 70 195 80 180Z" fill="var(--scrub)"/><g class="namaste"><path d="M58 182Q58 232 93 208" fill="none" stroke="var(--scrub)" stroke-width="22" stroke-linecap="round"/><path d="M142 182Q142 232 107 208" fill="none" stroke="var(--scrub)" stroke-width="22" stroke-linecap="round"/><path d="M100 168C112 178 114 200 100 214 86 200 88 178 100 168Z" fill="var(--skin)" stroke="#c99870" stroke-width="1.5"/></g><g class="arm"><path d="M150 160L182 98 170 92 138 150Z" fill="var(--scrub)"/><circle cx="176" cy="92" r="12" fill="var(--skin)"/></g></g></svg>`; }

// ---------- voice announcements ----------
const LANGS = { en: 'English', hi: 'हिन्दी', mr: 'मराठी', ta: 'தமிழ்', te: 'తెలుగు', bn: 'বাংলা' };
const LC = { en: 'en-IN', hi: 'hi-IN', mr: 'mr-IN', ta: 'ta-IN', te: 'te-IN', bn: 'bn-IN' };
const W = { counter: { en: 'counter', hi: 'काउंटर', mr: 'काउंटर', ta: 'கவுண்டர்', te: 'కౌంటర్', bn: 'কাউন্টার' }, room: { en: 'room', hi: 'कमरा', mr: 'खोली', ta: 'அறை', te: 'గది', bn: 'কক্ষ' } };
const M = {
  en: (n, w, p) => `Token number ${n}, please proceed to ${w} ${p}.`,
  hi: (n, w, p) => `टोकन नंबर ${n}, कृपया ${w} नंबर ${p} पर आइए।`,
  mr: (n, w, p) => `टोकन क्रमांक ${n}, कृपया ${w} क्रमांक ${p} मध्ये या.`,
  ta: (n, w, p) => `டோக்கன் எண் ${n}, தயவுசெய்து ${w} எண் ${p} க்கு வாருங்கள்.`,
  te: (n, w, p) => `టోకెన్ నంబర్ ${n}, దయచేసి ${w} నంబర్ ${p} కి రండి.`,
  bn: (n, w, p) => `টোকেন নম্বর ${n}, অনুগ্রহ করে ${p} নম্বর ${w}-এ আসুন।`,
};
// Wording styles (Admin → Settings → Announcements)
const STYLES = {
  en: { short: (n, w, p) => `Token ${n}, ${w} ${p}.`, polite: (n, w, p) => `Attention please. Token number ${n}, kindly proceed to ${w} number ${p}. Thank you.` },
  hi: { short: (n, w, p) => `टोकन ${n}, ${w} ${p}।`, polite: (n, w, p) => `कृपया ध्यान दें। टोकन नंबर ${n}, कृपया ${w} नंबर ${p} पर पधारें। धन्यवाद।` },
};
const phrase = (l, S, ...a) => (STYLES[l]?.[l === 'hi' ? S.styleHi : S.styleEn] || M[l])(...a);
const TONES = { soft: [660, 880], bell: [880, 1320, 880], triple: [700, 700, 700], single: [800], beep: [1000, 1000], ring: [988, 784, 988, 784, 988, 784], none: [] };
let audioCtx;
function chime(k) {
  try {
    audioCtx ||= new AudioContext();
    if (audioCtx.state === 'suspended') audioCtx.resume();
    const a = audioCtx, t = a.currentTime;
    (TONES[k] || []).forEach((f, i) => {
      const o = a.createOscillator(), g = a.createGain(), s = t + i * .25;
      o.frequency.value = f; o.connect(g); g.connect(a.destination);
      g.gain.setValueAtTime(.0001, s); g.gain.exponentialRampToValueAtTime(.25, s + .03); g.gain.exponentialRampToValueAtTime(.0001, s + .5);
      o.start(s); o.stop(s + .55);
    });
  } catch (e) { }
}
// "N-012" is spoken as "N 12" so voices read it naturally
const spoken = tok => tok.replace(/^([A-Z]+)-0*(\d+)$/, '$1 $2');
const callText = (c, S) => S.langs.map(l => phrase(l, S, spoken(c.token), W[c.kind][l], c.place)).join('   ');
// Best voice for a language on this computer: the one chosen in Admin if this PC has it,
// otherwise prefer natural/online voices (e.g. Edge "Swara Online (Natural)", Chrome "Google हिन्दी")
function pickVoice(lang, name) {
  const vs = 'speechSynthesis' in window ? speechSynthesis.getVoices() : [];
  if (name) { const v = vs.find(x => x.name === name); if (v) return v; }
  const score = v => (/natural/i.test(v.name) ? 8 : 0) + (/online/i.test(v.name) ? 4 : 0) + (/google/i.test(v.name) ? 3 : 0) + (/-IN$/i.test(v.lang.replace('_', '-')) ? 1 : 0);
  return vs.filter(v => v.lang.replace('_', '-').toLowerCase().startsWith(lang)).sort((a, b) => score(b) - score(a))[0] || null;
}
const speaking = []; // keep utterances referenced: Chrome drops events of garbage-collected ones and stops the sequence
function announce(c, S, { stage, character, onDone } = {}) {
  if (S.audio === false) { stage?.classList.add('calling'); setTimeout(() => { stage?.classList.remove('calling'); onDone?.(); }, 5000); return; } // sound off for this screen (Admin)
  const seq = [];
  for (let r = 0; r < (S.repeat || 1); r++) seq.push(...S.langs);
  stage?.classList.add('calling');
  if ('speechSynthesis' in window) speechSynthesis.cancel();
  chime(c.kind === 'room' ? S.toneRoom : S.toneCounter);
  if (!('speechSynthesis' in window)) return;
  setTimeout(() => (function go(i) {
    if (i >= seq.length) { setTimeout(() => { stage?.classList.remove('calling'); onDone?.(); }, 3000); return; }
    const l = seq[i], vc = S.voice?.[l] || {};
    const u = new SpeechSynthesisUtterance(phrase(l, S, spoken(c.token), W[c.kind][l], c.place));
    u.lang = LC[l]; u.rate = vc.rate || S.rate || 0.95; u.pitch = vc.pitch || 1; u.volume = S.volume ?? 1;
    const v = pickVoice(l, vc.name); if (v) u.voice = v;
    let done = false;
    const next = () => { if (done) return; done = true; clearTimeout(guard); speaking.splice(speaking.indexOf(u), 1); character?.classList.remove('talk'); setTimeout(() => go(i + 1), 250); };
    const guard = setTimeout(next, 4000 + u.text.length * 160); // carry on even if the browser never reports the end
    u.onstart = () => character?.classList.add('talk');
    u.onend = u.onerror = next;
    speaking.push(u); speechSynthesis.resume(); speechSynthesis.speak(u);
  })(0), 900);
}
if ('speechSynthesis' in window) speechSynthesis.getVoices();

function clock(el, withDate) {
  const tick = () => {
    const d = new Date();
    el.innerHTML = `<b>${d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</b>` +
      (withDate ? `<small>${d.toLocaleDateString([], { weekday: 'long', day: 'numeric', month: 'long' })}</small>` : '');
  };
  tick(); setInterval(tick, 1000);
}

// ---------- sound on staff desks ----------
// Staff desks play the chime and spoken announcement on their own computer when they call or recall,
// so sound works even when no TV display is open. The toggle is remembered per computer.
const deskSoundOn = () => { try { return localStorage.deskSound !== 'off'; } catch { return true; } };
function soundToggle() {
  return `<button class="btn sm ${deskSoundOn() ? '' : 'danger'}" id="sndBtn" title="Sound on this computer">${deskSoundOn() ? ICON.sound + ' Sound on' : ICON.mute + ' Sound off'}</button>`;
}
function wireSoundToggle(getS) {
  const b = $('#sndBtn'); if (!b) return;
  b.onclick = () => {
    try { localStorage.deskSound = deskSoundOn() ? 'off' : 'on'; } catch { }
    b.outerHTML = soundToggle(); wireSoundToggle(getS);
    if (deskSoundOn()) { const S = getS(); chime(S?.settings.toneCounter || 'soft'); toast('Sound is on for this computer'); }
  };
}
function deskAnnounce(c, S, key) { if (c && deskSoundOn()) announce(c, displayCfg(S.settings, key)); }
// Back/Home for full-screen displays: shown when the mouse moves, hidden after a few seconds
function floatNav() {
  const n = document.createElement('div'); n.innerHTML = navButtons('float'); const el = n.firstElementChild;
  document.body.append(el);
  let t; const wake = () => { el.classList.remove('idle'); clearTimeout(t); t = setTimeout(() => el.classList.add('idle'), 4000); };
  ['mousemove', 'touchstart', 'keydown'].forEach(e => addEventListener(e, wake, { passive: true })); wake();
}

// Printed token slip (kiosk and counter reprint)
function slipHTML(r, st, qr) {
  const d = r.dept;
  return `${st.logo ? `<img class="slip-logo" src="${esc(st.logo)}" alt="">` : ''}<div class="h">${esc(st.hospital)}</div>${st.building ? `<div class="small" style="color:#555">${esc(st.building)}</div>` : ''}
    <div class="d">${esc(d.name)} ${d.name_local ? '· ' + esc(d.name_local) : ''}${d.location ? `<div class="small">${esc(d.location)}</div>` : ''}</div>
    <div class="num">${esc(r.token)}</div>${r.priority ? `<div style="margin-top:8px">${priBadge(r.priority)}</div>` : ''}
    ${r.floor && r.status === 'waiting' ? `<div class="fl">Registration: ${esc(r.floor)} · Counter ${r.counters.join(', ')}</div>` : ''}
    ${r.doctor || r.room ? `<div class="fl">${r.doctor ? 'Dr. ' + esc(r.doctor) : ''}${r.doctor && r.room ? ' · ' : ''}${r.room ? 'Room ' + esc(r.room) : ''}${r.roomFloor ? ' (' + esc(r.roomFloor) + ')' : ''}</div>` : ''}
    ${r.name ? `<div class="small" style="margin-top:6px">${esc(r.name)}</div>` : ''}
    <div class="qr">${qr}</div><div class="small" style="color:#666">Scan to track your turn</div>
    <div class="meta">${r.status === 'waiting' ? `<div><b>${r.ahead}</b><span>Ahead of you</span></div>` : ''}${r.status === 'waiting' && r.waitMinutes != null ? `<div><b>~${r.waitMinutes} min</b><span>Est. wait</span></div>` : ''}<div><b>${fmtTime(r.issuedAt)}</b><span>${new Date(r.issuedAt).toLocaleDateString()}</span></div></div>`;
}

// ---------- motion helpers (v2.2) ----------
// Ripple on every button press
document.addEventListener('pointerdown', e => {
  const b = e.target.closest?.('.btn'); if (!b || b.disabled) return;
  const r = b.getBoundingClientRect(), d = Math.max(r.width, r.height), s = document.createElement('span');
  s.className = 'rip'; s.style.cssText = `width:${d}px;height:${d}px;left:${e.clientX - r.left - d / 2}px;top:${e.clientY - r.top - d / 2}px`;
  b.appendChild(s); setTimeout(() => s.remove(), 650);
});
// Flip big token numbers when they change; tick up small counters
const fxSeen = new Map();
function fxScan() {
  $$('.bigtk,.tok,.hero .num,[data-fx]').forEach((el, i) => {
    const key = (el.id || el.closest('[id]')?.id || '') + '|' + el.className.replace(/\s*fx-\w+/g, '') + '|' + i, v = el.textContent.trim();
    if (fxSeen.has(key) && fxSeen.get(key) !== v && v && v !== '—') { el.classList.remove('fx-flip'); void el.offsetWidth; el.classList.add('fx-flip'); }
    fxSeen.set(key, v);
  });
}
function ecgHTML() {
  const seg = 'l40 0 l8 -6 l6 6 l10 0 l6 -30 l8 54 l6 -30 l10 0 l10 -8 l10 8 l86 0';
  return `<div class="ecg"><svg viewBox="0 0 800 60" preserveAspectRatio="none"><path d="M0 34 ${seg} ${seg} ${seg} ${seg}"/></svg></div>`;
}

// ---------- phone app: install + push alerts (v3, WordPress) ----------
if ('serviceWorker' in navigator && PGI.base) navigator.serviceWorker.register(PGI.base + 'sw.js', { scope: PGI.base }).catch(() => { });
// A push arriving while the page is open refreshes it at once
navigator.serviceWorker?.addEventListener('message', e => { if (e.data?.pgiPush) live.refresh?.(); });
let pgiInstall = null;
window.addEventListener('beforeinstallprompt', e => { e.preventDefault(); pgiInstall = e; $$('.pgi-install').forEach(b => b.hidden = false); });
const isIOS = () => /iphone|ipad|ipod/i.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
const isStandalone = () => matchMedia('(display-mode: standalone)').matches || navigator.standalone === true;
function b64ToBytes(s) { s = s.replace(/-/g, '+').replace(/_/g, '/'); s += '='.repeat((4 - s.length % 4) % 4); return Uint8Array.from(atob(s), c => c.charCodeAt(0)); }
// Card that turns on alerts for this phone. opts: { kind: 'patient'|'doctor'|'ha', id, k, room, doctor, title, text }
function pushCard(el, opts) {
  const key = 'pgiPush:' + opts.kind + (opts.kind === 'patient' ? ':' + opts.id : ''); // staff keep alerts when they change room
  const hint = (t, cls = '') => `<p class="small ${cls}" style="margin:8px 0 0">${t}</p>`;
  const install = `<button class="btn sm pgi-install" ${pgiInstall ? '' : 'hidden'}>${ICON.plus || '＋'} Install app</button>`;
  const draw = async () => {
    let body = '', acts = '';
    if (isIOS() && !isStandalone()) {
      body = hint('On iPhone: tap the <b>Share</b> button <span aria-hidden="true">⬆︎</span>, then <b>Add to Home Screen</b>. Open the app from the new icon and turn alerts on there.<br>iPhone पर: Share दबाएं, फिर "Add to Home Screen" चुनें।', 'muted');
    } else if (!('serviceWorker' in navigator) || !('PushManager' in window) || !window.Notification) {
      body = hint('This browser cannot show alerts. Use Chrome on Android, or Safari on iPhone (iOS 16.4 or newer).', 'muted');
    } else if (!PGI.vapid) {
      body = hint('Alerts are not set up on the server yet (Admin: run the setup again).', 'muted');
    } else if (Notification.permission === 'denied') {
      body = hint('Alerts are blocked for this site. Allow notifications in the phone settings, then reload.', 'muted');
    } else {
      const reg = await navigator.serviceWorker.ready.catch(() => null);
      const sub = await reg?.pushManager.getSubscription().catch(() => null);
      const on = sub && localStorage.getItem(key) === sub.endpoint;
      body = hint(on ? '✓ Alerts are on for this phone, even when the screen is off.<br>सूचनाएं चालू हैं।' : esc(opts.text || 'Get an alert on this phone.'), on ? '' : 'muted');
      acts = on ? `<button class="btn sm" data-a="test">Send test alert</button><button class="btn ghost sm" data-a="off">Turn off</button>`
        : `<button class="btn primary sm" data-a="on">${ICON.bell} Turn on alerts</button>`;
    }
    el.innerHTML = `<section class="card pushcard"><div class="card-h"><h3>${esc(opts.title || 'Phone alerts')}</h3><div class="row">${install}${acts}</div></div>${body}</section>`;
    el.querySelector('.pgi-install').onclick = async () => { if (!pgiInstall) return; pgiInstall.prompt(); await pgiInstall.userChoice.catch(() => { }); pgiInstall = null; draw(); };
    el.querySelectorAll('[data-a]').forEach(b => b.onclick = () => run(b.dataset.a, b));
  };
  const run = async (a, btn) => {
    btn.disabled = true;
    try {
      const reg = await navigator.serviceWorker.ready;
      if (a === 'on') {
        if (await Notification.requestPermission() !== 'granted') throw new Error('Alerts were not allowed');
        const sub = (await reg.pushManager.getSubscription()) || await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64ToBytes(PGI.vapid) });
        const r = await api('push-subscribe', { sub: sub.toJSON(), kind: opts.kind, id: opts.id, k: opts.k, room: opts.room, doctor: opts.doctor });
        if (r.error) throw new Error(r.error);
        Object.keys(localStorage).filter(x => x.startsWith('pgiPush:')).forEach(x => localStorage.removeItem(x)); // one phone, one alert type
        localStorage.setItem(key, sub.endpoint); toast('Alerts turned on');
      } else {
        const sub = await reg.pushManager.getSubscription();
        if (a === 'test') { const r = await api('push-test', { endpoint: sub?.endpoint }); if (r.error) throw new Error(r.error); toast('Test alert sent'); }
        if (a === 'off') { if (sub) { await api('push-unsubscribe', { endpoint: sub.endpoint }); await sub.unsubscribe(); } localStorage.removeItem(key); }
      }
    } catch (e) { toast(e.message || 'Could not turn on alerts', true); }
    draw();
  };
  draw();
  return { update(o) { const changed = o.room !== opts.room || o.doctor !== opts.doctor; Object.assign(opts, o); if (!changed) return; if (localStorage.getItem(key)) run('on', {}); else draw(); } };
}
