// Service worker: makes the token system installable and shows push alerts while the app is closed
const OFFLINE = '<!DOCTYPE html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Offline</title>'
  + '<body style="font-family:system-ui;display:grid;place-items:center;min-height:90vh;text-align:center;color:#0f766e"><div><h2>No internet connection</h2>'
  + '<p>इंटरनेट कनेक्शन नहीं है</p><button onclick="location.reload()" style="font-size:1.1rem;padding:12px 26px;border-radius:12px;border:0;background:#0f766e;color:#fff">Try again</button></div>';
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', e => e.waitUntil(self.clients.claim()));
// Pages always come from the server (live data); only a friendly page is shown when offline
self.addEventListener('fetch', e => {
  if (e.request.mode !== 'navigate') return;
  e.respondWith(fetch(e.request).catch(() => new Response(OFFLINE, { headers: { 'Content-Type': 'text/html; charset=utf-8' } })));
});
self.addEventListener('push', e => {
  let m = {};
  try { m = e.data ? e.data.json() : {}; } catch { m = { body: e.data ? e.data.text() : '' }; }
  const ring = m.kind === 'ring';
  e.waitUntil((async () => {
    await self.registration.showNotification(m.title || 'Token update', {
      body: m.body || '', tag: m.tag || 'pgi', renotify: true, requireInteraction: ring || m.kind === 'patient',
      icon: 'icon-192.png', badge: 'icon-192.png', data: { url: m.url || './' },
      vibrate: ring ? [600, 200, 600, 200, 600, 200, 600] : [300, 120, 300], silent: false,
    });
    // Tell open screens so they refresh at once
    (await self.clients.matchAll({ type: 'window' })).forEach(c => c.postMessage({ pgiPush: m }));
  })());
});
self.addEventListener('notificationclick', e => {
  e.notification.close();
  const url = new URL(e.notification.data?.url || './', self.registration.scope).href;
  e.waitUntil((async () => {
    const all = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    const same = all.find(c => c.url === url) || all.find(c => c.url.startsWith(self.registration.scope));
    if (same) { await same.focus(); if (same.url !== url && 'navigate' in same) return same.navigate(url); return; }
    return self.clients.openWindow(url);
  })());
});
