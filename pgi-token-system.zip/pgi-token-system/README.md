# PGI Token System for WordPress (v3.0.2)

This is the hospital token and queue system as a WordPress plugin. Every token, patient detail, doctor and report is saved in the website's own database. Staff and patients open it in a browser, and phones can add it to the Home Screen as an app that gets push alerts.

## What you need

- A WordPress website (6.0 or newer) on a host with PHP 7.4 or newer and MySQL or MariaDB. Most Indian hosting plans meet this.
- **HTTPS (an SSL certificate)**. Phones only install the app and receive alerts on an `https://` site. Most hosts give free SSL (Let's Encrypt).
- The PHP OpenSSL extension, which is on by default almost everywhere. Without it everything still works, but phone alerts stay off.

## Install

1. In WordPress go to **Plugins → Add New → Upload Plugin** and choose `pgi-token-system.zip`.
2. Click **Activate**. The **setup wizard** opens by itself and has five steps:
   1. **Check:** confirms PHP, HTTPS and push support.
   2. **Hospital:** sets the hospital name, building and colour theme.
   3. **Counters and rooms:** sets the counters on each floor, the number of doctor rooms and which floor the rooms are on.
   4. **Doctors:** loads the PGIMER Neurology and Neurosurgery OPD list with each doctor's days.
   5. **Staff logins:** creates the Admin, Counter, Doctor and Attendant accounts. Each password must be at least 8 characters.
3. When it finishes it shows the links and QR codes for every screen.

You can run the wizard again later from the **PGI Token → Setup wizard** menu. When you run it again, leave a password empty to keep it unchanged.

The wizard turns on WordPress "pretty links" (Settings → Permalinks), because the app lives at `https://your-site/token/`.

## The screens

| Screen | Address | Who |
|---|---|---|
| Home | `/token/` | everyone |
| Token kiosk | `/token/kiosk.html` | patients (touch screen + printer) |
| Hall TV | `/token/display.html` | TVs at the counters |
| Room TV | `/token/room.html?room=1` | TV outside a doctor room |
| Registration counter | `/token/counter.html` | counter staff |
| Doctor desk | `/token/doctor.html` | doctors |
| Room attendant | `/token/ha.html` | attendants' phones |
| Admin | `/token/admin.html` | admin (asks for the password every time) |
| My token | from the QR on the slip | patients' phones |

## Phone app

- **Android (Chrome):** open the page, then tap **Install app** on the page or in the ⋮ menu.
- **iPhone (Safari, iOS 16.4 or newer):** open the page, tap **Share**, then **Add to Home Screen**. Open the app from the new icon. Apple only allows alerts in the Home Screen app.

The installed app opens on the page it was added from. For example, an attendant who adds `ha.html?room=2` gets an app that opens on Room 2.

## Push alerts

Tap **Turn on alerts**, then **Allow**. **Send test alert** checks that it works.

| Who | Where to turn it on | They are alerted when |
|---|---|---|
| Patient | the "My token" page from the slip QR | their token is called to a counter or a room |
| Room attendant | `ha.html` | the doctor presses **Call attendant** (the alert stays until opened), and when a new patient is sent to their room |
| Doctor | `doctor.html` | a new patient is sent to their room |

New-patient alerts follow the **Doctor beep** switch in Admin → Settings → Displays & sound.

Alerts work over mobile data, so attendants don't need the hospital Wi-Fi. Patient alerts stop at midnight along with the token.

## Updates (one click)

Go to **PGI Token → Updates** and enter where new versions are published. You can use either:

- a public GitHub repository, such as `your-name/pgi-token-system` (a pasted github.com link also works), or
- a link to a small update file on any website: `{"version":"3.1.0","download_url":"https://…/pgi-token-system.zip","notes":"What changed"}`.

Then press **Save and check now**. When a newer version exists, the page shows what changed and an **Update now** button. The Plugins page shows **update now** as well. WordPress checks by itself twice a day, and you can turn on **Enable auto-updates** on the Plugins page if you prefer.

Updating keeps all tokens, doctors, settings and logins. Open screens (TVs, kiosk, phones) notice the new version and reload by themselves.

### Publishing a new version on GitHub

1. Create a **public** repository, for example `pgi-token-system`. Upload the contents of this plugin folder (`pgi-token-system.php`, `includes/`, `app/`, `README.md`) to its top level. The code holds no patient data or passwords.
2. For each new version, raise the version number in `pgi-token-system.php` in both places (`Version: 3.1.0` and `define('PGI_VERSION', '3.1.0')`).
3. On GitHub, open **Releases → Draft a new release**. Create the tag `v3.1.0` (the same number), write what changed, and press **Publish release**.
   - Attaching a `pgi-token-system.zip` to the release is optional. Without it, GitHub's own source-code zip is used.

The tag and the number in the file must match. If they don't, WordPress keeps offering the same update.

## Notes

- **Live updates:** screens check for changes every 2 seconds, or every 5 seconds when in the background. Only changes are downloaded.
- **Day change:** at the first request after midnight, the previous day's open tokens are marked **Missed** and kept for Admin → Reports. The date uses the WordPress timezone (Settings → General). Set it to **Kolkata**.
- **Staff accounts:** these are normal WordPress users with the roles *PGI Token admin*, *PGI Registration counter*, *PGI Doctor* and *PGI Room attendant*. WordPress administrators can open every screen.
- **Removing the plugin:** your data is kept. The tables are called `wp_pgi_*`.

## Privacy

Patient names and phone numbers are now stored on an internet server, so take these precautions:

- Use HTTPS.
- Use strong staff passwords.
- Keep WordPress and plugins updated.
- Take regular backups.
- Get the hospital IT team's approval for where the site is hosted. Keep it in India if hospital policy (and the DPDP Act) requires that.
